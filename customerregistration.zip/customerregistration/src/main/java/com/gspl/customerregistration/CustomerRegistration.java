package com.gspl.customerregistration;

import java.util.Locale;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.support.ResourceBundleMessageSource;

import com.fasterxml.jackson.databind.Module;
import com.fasterxml.jackson.datatype.hibernate5.jakarta.Hibernate5JakartaModule;

@SpringBootApplication
public class CustomerRegistration extends SpringBootServletInitializer {

	private static volatile ConfigurableApplicationContext context;
	private static ClassLoader mainThreadClassLoader;

//	public static void main(String[] args) {
//		SpringApplication.run(CustomerRegistration.class, args);
//
//	}

	public static void main(String[] args) {
		mainThreadClassLoader = Thread.currentThread().getContextClassLoader();
		context = SpringApplication.run(CustomerRegistration.class, args);
	}

	public static void restart() {
		ApplicationArguments args = context.getBean(ApplicationArguments.class);

		Thread thread = new Thread(() -> {
			context.close();
			context = SpringApplication.run(CustomerRegistration.class, args.getSourceArgs());
		});

		thread.setContextClassLoader(mainThreadClassLoader);
		thread.setDaemon(false);
		thread.start();
	}

//	@Bean
//	LocaleResolver localeResolver() {
//		SessionLocaleResolver localResolver = new SessionLocaleResolver();
//		localResolver.setDefaultLocale(Locale.getDefault());
//		return localResolver;
//	}

	@Bean
	Module hibernateModule() { // For lazy initialization
		return new Hibernate5JakartaModule();
	}

	@Bean(name = "messages")
	MessageSource messageResource() {
		ResourceBundleMessageSource messageBundleResrc = new ResourceBundleMessageSource();
		messageBundleResrc.setBasename("messages");
		messageBundleResrc.setDefaultLocale(Locale.getDefault());
		messageBundleResrc.setFallbackToSystemLocale(true);
		messageBundleResrc.setUseCodeAsDefaultMessage(true);
		messageBundleResrc.setAlwaysUseMessageFormat(true);
		return messageBundleResrc;
	}

//	@Bean(name = "CMSResources")
//	MessageSource cmsResources() {
//		ResourceBundleMessageSource messageBundleResrc = new ResourceBundleMessageSource();
//		messageBundleResrc.setBasename("CMSResources");
//		return messageBundleResrc;
//	}
	// mvn pmd:check checkstyle:checkstyle clean install spring-boot:run

}
