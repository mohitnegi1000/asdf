package com.gspl.customerregistration.security;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.servlet.HandlerExceptionResolver;

import io.jsonwebtoken.Claims;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.log4j.Log4j2;

@Log4j2
@Component
public final class JwtAuthenticationFilter extends OncePerRequestFilter {
	private final HandlerExceptionResolver handlerExceptionResolver;
	private final JwtService jwtService;

	@Autowired
	@Qualifier("authMapping")
	private Map<String, Integer> authMapping;

	@Autowired
	@Qualifier("authMappingDefaults")
	private Map<String, Integer> authMappingDefaults;

	private JwtAuthenticationFilter(JwtService jwtService, HandlerExceptionResolver handlerExceptionResolver) {
		this.jwtService = jwtService;
		this.handlerExceptionResolver = handlerExceptionResolver;
	}

	@Override
	protected void doFilterInternal(@NonNull HttpServletRequest request, @NonNull HttpServletResponse response, @NonNull FilterChain filterChain)
			throws ServletException, IOException {

		String jwt = request.getHeader("Authentication");

		try {

			if (jwt == null || jwt.isEmpty()) {
				throw new Exception("Unauthorized");
			}

			final String username = jwtService.extractUsername(jwt);
//			final int entityTypeId = (int) jwtService.extractClaim(jwt, (Claims c) -> c.get("entityTypeId"));

//			MyUserDetails userDetails = new MyUserDetails(username, entityTypeId);

			if (jwtService.isTokenValidByUSername(jwt, username)) {

//				UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(userDetails, null,
//						userDetails.getAuthorities());
//				authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
//				SecurityContextHolder.getContext().setAuthentication(authToken);

				final List<String> authIds = (List<String>) jwtService.extractClaim(jwt, (Claims c) -> c.get("authIds"));
				int authId = authMapping.getOrDefault(request.getServletPath(), 0);
				if (authMappingDefaults.containsValue(authId)) {
					log.info("DEFAULT ALLWOWED");
				} else if (authId == 0 || !authIds.contains(String.valueOf(authId))) {
					log.info("Unauthorized");
					//throw new Exception("Unauthorized");
				}

			}

			filterChain.doFilter(request, response);
		} catch (Exception exception) {
			response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			handlerExceptionResolver.resolveException(request, response, null, exception);
		}
	}

}
