package com.gspl.customerregistration.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import com.gspl.customerregistration.entity.CustomerTypeEntity;

public interface RepoCustomerType extends JpaRepository<CustomerTypeEntity, Integer>, CrudRepository<CustomerTypeEntity, Integer> {

}
