package com.gspl.customerregistration.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gspl.customerregistration.entity.InstallationTaskList;

public interface RepoInstallationTaskList extends JpaRepository<InstallationTaskList, Long> {

}
