package com.gspl.customerregistration.security;

import java.security.Key;
import java.util.Date;
import java.util.Locale;
import java.util.function.Function;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.UnsupportedJwtException;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import io.jsonwebtoken.security.SignatureException;

@Service
public class JwtService {
	@Value("${security.jwt.secret-key}")
	private String secretKey;

	@Value("${security.jwt.expiration-time}")
	private long jwtExpiration;

	@Autowired
	@Qualifier("messages")
	private MessageSource messageResource;

	public String extractUsername(String token) {
		return extractClaim(token, Claims::getSubject);
	}

	public <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
		final Claims claims = extractAllClaims(token);
		return claimsResolver.apply(claims);
	}

	public long getExpirationTime() {
		return jwtExpiration;
	}

	public boolean isTokenValidByUSername(String token, String userName) {
		final String username = extractUsername(token);
		return username.equals(userName) && !isTokenExpired(token);
	}

	private boolean isTokenExpired(String token) {
		return extractExpiration(token).before(new Date());
	}

	private Date extractExpiration(String token) {
		return extractClaim(token, Claims::getExpiration);
	}

	private Claims extractAllClaims(String token) {
		try {
			return Jwts.parserBuilder().setSigningKey(getSignInKey()).build().parseClaimsJws(token).getBody();
		} catch (SignatureException e) {
			throw new SignatureException(messageResource.getMessage("invalid.jwt.sign", null, "_", Locale.getDefault()));
		} catch (ExpiredJwtException e) {
			throw new ExpiredJwtException(null, null, messageResource.getMessage("expired.jwt", null, "_", Locale.getDefault()));
		} catch (UnsupportedJwtException e) {
			throw new UnsupportedJwtException(messageResource.getMessage("wrong.jwt", null, "_", Locale.getDefault()));
		} catch (MalformedJwtException e) {
			throw new MalformedJwtException(messageResource.getMessage("malform.jwt", null, "_", Locale.getDefault()));
		} catch (IllegalArgumentException e) {
			throw new IllegalArgumentException(messageResource.getMessage("illegal.args", null, "_", Locale.getDefault()));
		}
	}

	private Key getSignInKey() {
		byte[] keyBytes = Decoders.BASE64.decode(secretKey);
		return Keys.hmacShaKeyFor(keyBytes);
	}
}
