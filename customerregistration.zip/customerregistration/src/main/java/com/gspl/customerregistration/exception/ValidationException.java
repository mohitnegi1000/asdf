package com.gspl.customerregistration.exception;

public class ValidationException extends Exception {

	public ValidationException(String msg) {
		super(msg);
	}

	public ValidationException() {

	}

}
