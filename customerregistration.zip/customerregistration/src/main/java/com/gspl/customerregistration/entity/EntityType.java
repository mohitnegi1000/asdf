package com.gspl.customerregistration.entity;

import org.springframework.data.jpa.domain.Specification;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "entityType")
public class EntityType {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int entityTypeId;

	private String entityTypeName = "";
	private String entityTypeCode = "";

	public static Specification<EntityType> specsEqual() {
		return (root, query, cb) -> cb.notEqual(root.get("entityTypeId"), "0");
	}
}
