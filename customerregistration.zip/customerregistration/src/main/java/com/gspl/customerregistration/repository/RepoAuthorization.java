package com.gspl.customerregistration.repository;

import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.gspl.customerregistration.entity.AuthorizationEntity;

public interface RepoAuthorization extends JpaRepository<AuthorizationEntity, Integer>, CrudRepository<AuthorizationEntity, Integer> {

//	List<AuthorizationEntity> findByIsMenuItemTrueAndEntityTypeEntityTypeId(int entityTypeId);

	@Query(value = """
			SELECT SUM(AUTHORIZATION_ID) AS AUTHORIZATION_ID,
				0 AS ENTITY_TYPE_ENTITY_TYPE_ID,
				FALSE AS IS_MENU_ITEM,
				-1 AS PARENT_ID,
				AUTHORIZATION_MAPPING,
				STRING_AGG(CT.ENTITY_TYPE_ENTITY_TYPE_ID::text,',') AS AUTHORIZATION_NAME,
				STRING_AGG((SELECT ENTITY_TYPE_CODE FROM ENTITY_TYPE CTC WHERE CTC.ENTITY_TYPE_ID = CT.ENTITY_TYPE_ENTITY_TYPE_ID)::text,',') AS ICON,
				'' AS AUTHORIZATIONMS
			FROM AUTHORIZATION_DATA CT
			WHERE AUTHORIZATIONMS = :authms
			GROUP BY CT.AUTHORIZATION_MAPPING
			ORDER BY RIGHT(AUTHORIZATION_MAPPING,1) DESC
				""", nativeQuery = true)
	List<AuthorizationEntity> findGroupByNative(String authms);

	@Query(value = """
			SELECT AUTHORIZATION_MAPPING AS AUTHORIZATIONMAPPING,
				   STRING_AGG(CT.ENTITY_TYPE_ENTITY_TYPE_ID::text,',') AS ENTITYTYPEID,
				   STRING_AGG((SELECT ENTITY_TYPE_CODE FROM ENTITY_TYPE CTC WHERE CTC.ENTITY_TYPE_ID = CT.ENTITY_TYPE_ENTITY_TYPE_ID)::text,',') AS ENTITYTYPECODE
			FROM AUTHORIZATION_DATA CT
			WHERE AUTHORIZATIONMS = :authms
			GROUP BY CT.AUTHORIZATION_MAPPING
			ORDER BY RIGHT(AUTHORIZATION_MAPPING,1) DESC
				""", nativeQuery = true)
	List<Map<String, String>> springSecurityAuths(String authms);

	@Query("SELECT new AuthorizationEntity(CAE.authorizationMapping as  authorizationMapping, CAE.authorizationId as authorizationId) FROM AuthorizationEntity CAE")
	List<AuthorizationEntity> getAuthObject();

	@Query("SELECT new AuthorizationEntity(CAE.authorizationMapping as  authorizationMapping, CAE.authorizationId as authorizationId) FROM AuthorizationEntity CAE WHERE CAE.isDefault=true")
	List<AuthorizationEntity> getAuthObjectDefaults();

}
