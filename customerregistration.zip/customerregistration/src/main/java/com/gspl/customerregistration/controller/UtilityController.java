package com.gspl.customerregistration.controller;

import java.io.File;
import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gspl.customerregistration.security.JwtService;
import com.gspl.customerregistration.service.RestWebClient;

import io.jsonwebtoken.Claims;
import lombok.extern.log4j.Log4j2;

@Log4j2
@RestController
@RequestMapping("/Utility")
public class UtilityController {

	@Autowired
	RestWebClient restWebClient;

	@Autowired
	private JwtService jwtService;

	@GetMapping("/restart")
	public ResponseEntity<String> restart(@RequestHeader(name = "Authentication") String authentication) {
		int entityType = (int) jwtService.extractClaim(authentication, (Claims c) -> c.get("entityTypeId"));
		if (entityType != 1) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized");
		}
//		CustomerRegistration.restart();
		return ResponseEntity.ok("OK");
	}

	@GetMapping("/downloadFile")
	public ResponseEntity<UrlResource> downloadFile(@RequestParam String fileName) {
		try {
			File file = new File("src/main/resources/", fileName);
			UrlResource res = new UrlResource(file.toURI());
			return ResponseEntity.ok().contentType(MediaType.parseMediaType("application/octet-stream"))
					.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"").body(res);
		} catch (MalformedURLException e) {
			log.error("error", e);
		}
		return ResponseEntity.status(HttpStatus.NO_CONTENT).body(null);
	}

	@GetMapping("/webClient")
	public ResponseEntity<Map<String, Object>> webClient(@RequestHeader(name = "Authentication") String authentication,
			@RequestParam int entityTypeId) {
		HashMap<String, Object> param = new HashMap<>() {
			{
				put("entityTypeId", entityTypeId);
			}
		};

		HashMap<String, String> header = new HashMap<>() {
			{
				put("Authentication", authentication);
			}
		};

		HashMap<String, Object> body = new HashMap<>() {
			{
				put("username", "superadminIN");
				put("password", "Password@123");
			}
		};

		JSONObject job = restWebClient.getJsonObject(HttpMethod.GET, "http://localhost:8084/AuthenticationService", "/moduleList", param, header,
				body, authentication);

		// System.out.println("JSONOBJECT ::: " + job.get("moduleList"));
		return ResponseEntity.ok(job.toMap());
	}

}
