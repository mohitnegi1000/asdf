package com.gspl.customerregistration.controller;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.gspl.customerregistration.entity.CityEntity;
import com.gspl.customerregistration.entity.LocalityEntity;
import com.gspl.customerregistration.entity.StateEntity;
import com.gspl.customerregistration.service.GeographicalLocationService;

@RestController
@RequestMapping("/GeographicalLocation")
public class GeographicalLocationController {
	@Autowired
	private GeographicalLocationService geographicalLocationService;

	@Autowired
	@Qualifier("messages")
	private MessageSource messageResource;

	@GetMapping("/getStatesFromCountry")
	public ResponseEntity<List<StateEntity>> getStatesFromCountry(@RequestParam int countryId) {
		try {
			List<StateEntity> states = geographicalLocationService.getAllStatesAsPerCountry(countryId);
			return ResponseEntity.ok(states);
		} catch (Exception e) {
			return ResponseEntity.noContent().build();
		}
	}

	@GetMapping("/getCitiesFromState")
	public ResponseEntity<List<CityEntity>> getCitiesFromStates(@RequestParam int stateId) {
		try {
			List<CityEntity> cities = geographicalLocationService.getAllCitiesAsPerState(stateId);
			return ResponseEntity.ok(cities);
		} catch (Exception e) {
			return ResponseEntity.noContent().build();
		}
	}

	@GetMapping("/getLocalitiesFromCity")
	public ResponseEntity<List<LocalityEntity>> getLocalitiesFromCity(@RequestParam int cityId) {
		try {
			List<LocalityEntity> localities = geographicalLocationService.getAllLocalitiessAsPerCity(cityId);
			return ResponseEntity.ok(localities);
		} catch (Exception e) {
			return ResponseEntity.noContent().build();
		}
	}

	@GetMapping("/getLocalitiesByPincode")
	public ResponseEntity<?> getLocalitiesByPincode(@RequestParam int pinCode) {
		List<LocalityEntity> localityData = geographicalLocationService.getLocalitesAsPerPinCode(pinCode);
		if (localityData != null && !localityData.isEmpty()) {
			return new ResponseEntity<>(localityData, HttpStatus.OK);
		}
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}

	@GetMapping("/getPincodeByLocality")
	public ResponseEntity<HashMap<String, String>> getPincodeByLocality(@RequestParam int localityId) {
		String pincode = geographicalLocationService.getPincodeByLocality(localityId);
		return ResponseEntity.ok(new HashMap<>() {
			{
				put("pincode", pincode);
			}
		});
	}

	@PostMapping("/stateUpload")
	public ResponseEntity<String> stateUpload(@RequestBody StateEntity stateEntity) {
		try {
			geographicalLocationService.uploadState(stateEntity.getCountryEntity(), "", stateEntity.getStateCode(), stateEntity.getStateName());
			return ResponseEntity.ok("State uploaded successfully.");
		} catch (Exception ex) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error: " + ex.getMessage());
		}
	}

	@PostMapping("/bulkStateUpload")
	public ArrayList<String> bulkStateUpload(@RequestPart(value = "file", required = false) MultipartFile file) throws FileNotFoundException {
		ArrayList<String> errBud = new ArrayList<>();
		if (file == null || file.isEmpty()) {
			errBud.add(messageResource.getMessage("file.empty", null, null, null));
			return errBud;
		}
		try (BufferedReader br = new BufferedReader(new InputStreamReader(file.getInputStream()))) {
			String line;
			int lineNo = 0;
			while ((line = br.readLine()) != null) {
				lineNo++;
				if (lineNo == 1) {
					continue;
				}
				String[] data = line.split(",", -1);
				if (data.length == 3) {
					try {
						geographicalLocationService.uploadState(null, data);
					} catch (Exception e) {
						errBud.add("Error on line " + lineNo + ": " + e.getMessage());
					}

				} else {
					errBud.add(messageResource.getMessage("incorrect.file.format", null, null, null) + " "
							+ messageResource.getMessage("error.line2", new Object[] { lineNo }, null, null));
				}
			}
			return errBud;
		} catch (Exception ex) {
			errBud.add(messageResource.getMessage("error", new Object[] { ex.getMessage() }, null, null));
		}
		return errBud;

	}

	@PostMapping("/cityUpload")
	public ResponseEntity<String> cityUpload(@RequestBody CityEntity cityEntity) {
		try {
			geographicalLocationService.uploadCity(cityEntity.getStateEntity(), "", cityEntity.getCityCode(), cityEntity.getCityName());
			return ResponseEntity.ok("City uploaded successfully.");
		} catch (Exception ex) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error: " + ex.getMessage());
		}
	}

	@PostMapping("/bulkCityUpload")
	public ArrayList<String> bulkCityUpload(@RequestPart(value = "file", required = false) MultipartFile file) throws FileNotFoundException {
		ArrayList<String> errBud = new ArrayList<>();
		if (file == null || file.isEmpty()) {
			errBud.add(messageResource.getMessage("file.empty", null, null, null));
			return errBud;
		}
		try (BufferedReader br = new BufferedReader(new InputStreamReader(file.getInputStream()))) {
			String line;
			int lineNo = 0;
			while ((line = br.readLine()) != null) {
				lineNo++;
				if (lineNo == 1) {
					continue;
				}
				String[] data = line.split(",", -1);
				if (data.length == 3) {
					try {
						geographicalLocationService.uploadCity(null, data);
					} catch (Exception e) {
						errBud.add("Error on line " + lineNo + ": " + e.getMessage());
					}

				} else {
					errBud.add(messageResource.getMessage("incorrect.file.format", null, null, null) + " "
							+ messageResource.getMessage("error.line2", new Object[] { lineNo }, null, null));
				}
			}
			return errBud;
		} catch (Exception ex) {
			errBud.add(messageResource.getMessage("error", new Object[] { ex.getMessage() }, null, null));
		}
		return errBud;

	}

	@PostMapping("/localityUpload")
	public ResponseEntity<String> localityUpload(@RequestBody LocalityEntity localityEntity) {
		try {
			geographicalLocationService.uploadLocality(localityEntity.getCityEntity(), "", localityEntity.getPincode(),
					localityEntity.getLocalityName());
			return ResponseEntity.ok("Locality uploaded successfully.");
		} catch (Exception ex) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error: " + ex.getMessage());
		}
	}

	@PostMapping("/bulkLocalityUpload")
	public ArrayList<String> bulkLocalityUpload(@RequestPart(value = "file", required = false) MultipartFile file) throws FileNotFoundException {
		ArrayList<String> errBud = new ArrayList<>();
		if (file == null || file.isEmpty()) {
			errBud.add(messageResource.getMessage("file.empty", null, null, null));
			return errBud;
		}
		try (BufferedReader br = new BufferedReader(new InputStreamReader(file.getInputStream()))) {
			String line;
			int lineNo = 0;
			while ((line = br.readLine()) != null) {
				lineNo++;
				if (lineNo == 1) {
					continue;
				}
				String[] data = line.split(",", -1);
				if (data.length == 3) {
					geographicalLocationService.uploadLocality(null, data);
				} else {

					errBud.add(messageResource.getMessage("incorrect.file.format", null, null, null) + " "
							+ messageResource.getMessage("error.line2", new Object[] { lineNo }, null, null));
				}
			}
			return errBud;
		} catch (Exception ex) {
			errBud.add(messageResource.getMessage("error", new Object[] { ex.getMessage() }, null, null));
		}
		return null;
	}

	@GetMapping("/getPincodeAndLocalityName")
	public List<LocalityEntity> getPincodeAndLocalityName() {
		return geographicalLocationService.getLocality();
	}

}
