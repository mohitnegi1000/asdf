
package com.gspl.customerregistration.service;

import java.util.HashMap;
import java.util.List;

import org.hibernate.Hibernate;
import org.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gspl.customerregistration.entity.CustomerEntity;
import com.gspl.customerregistration.entity.CustomerTypeEntity;
import com.gspl.customerregistration.exception.ValidationException;
import com.gspl.customerregistration.repository.RepoCustomer;
import com.gspl.customerregistration.repository.RepoCustomerType;
import com.gspl.customerregistration.utility.CommonUtilities;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Service
public class CustomerService {

	@Autowired
	private RepoCustomer repoCustomer;

	@Autowired
	private RepoCustomerType repoCustomerType;

	@Autowired
	@Qualifier("messages")
	private MessageSource messageResource;

	@Autowired
	private CommonUtilities commonUtilities;

	@Transactional
	public int createOrUpdateEntity(CustomerEntity customer, JSONArray errors) throws Exception {
		if (customer.getCustomerBDID() == 0) {
			errors.put(messageResource.getMessage("empty", new String[] { messageResource.getMessage("bdid", null, null, null) }, null, null));
		}
		if (customer.getCustomerName() == null || "".equals(customer.getCustomerName())) {
			errors.put(
					messageResource.getMessage("empty", new String[] { messageResource.getMessage("customer.name", null, null, null) }, null, null));
		}
		if (customer.getCustomerEmail() == null || "".equals(customer.getCustomerEmail())
				|| !commonUtilities.validateEmailReg(customer.getCustomerEmail())) {
			errors.put(messageResource.getMessage("invalid", new String[] { messageResource.getMessage("customer.mail", null, null, null) }, null,
					null));
		}
		if (customer.getRegisteredAddress() == null || "".equals(customer.getRegisteredAddress())) {
			errors.put(messageResource.getMessage("empty", new String[] { messageResource.getMessage("customer.address", null, null, null) }, null,
					null));
		}
		if (customer.getLocalityEntity() == null || customer.getLocalityEntity().getLocalityId() == 0) {
			errors.put(messageResource.getMessage("empty", new String[] { messageResource.getMessage("customer.locality", null, null, null) }, null,
					null));
		}
		if (customer.getCustomerTypeEntity() == null || customer.getCustomerTypeEntity().getCustomerTypeId() == 0) {
			errors.put(
					messageResource.getMessage("empty", new String[] { messageResource.getMessage("customer.type", null, null, null) }, null, null));
		}
		if (!errors.isEmpty()) {
			throw new ValidationException();
		}

		if (customer.getCustomerId() == 0) { // new
			if (repoCustomer.count(customerFilterSpecification(String.valueOf(customer.getCustomerBDID()), customer.getCustomerName(),
					customer.getCustomerEmail(), "", 0, 0, 0, 0, "", 0)) > 0) {
				throw new UsernameNotFoundException(
						messageResource.getMessage("exists", new String[] { messageResource.getMessage("user", null, null, null) }, null, null));
			}
			return repoCustomer.save(customer).getCustomerId();
		}
		if (repoCustomer.existsById(customer.getCustomerId())) { // update
			return repoCustomer.save(customer).getCustomerId();
		}
		throw new UsernameNotFoundException(messageResource.getMessage("user.absent", null, null, null));
	}

	public Specification<CustomerEntity> customerFilterSpecification(String customerBDID, String customerName, String customerEmail,
			String registeredAddress, int countryId, int stateId, int cityId, int localityId, String pincode, int customerTypeId) {
		return Specification.where(CustomerEntity.specsEqual())
				.and((root, query, cb) -> "".equals(customerBDID) ? cb.conjunction() : cb.equal(root.get("customerBDID"), customerBDID))
				.and((root, query, cb) -> countryId == 0 ? cb.conjunction()
						: cb.equal(root.get("localityEntity").get("cityEntity").get("stateEntity").get("countryEntity").get("countryId"), countryId))
				.and((root, query, cb) -> stateId == 0 ? cb.conjunction()
						: cb.equal(root.get("localityEntity").get("cityEntity").get("stateEntity").get("stateId"), stateId))
				.and((root, query, cb) -> cityId == 0 ? cb.conjunction()
						: cb.equal(root.get("localityEntity").get("cityEntity").get("cityId"), cityId))
				.and((root, query, cb) -> localityId == 0 ? cb.conjunction() : cb.equal(root.get("localityEntity").get("localityId"), localityId))
				.and((root, query, cb) -> pincode == null || "".equals(pincode) ? cb.conjunction()
						: cb.equal(root.get("localityEntity").get("pincode"), pincode))
				.and((root, query, cb) -> "".equals(customerName) ? cb.conjunction() : cb.like(root.get("customerName"), customerName))
				.and((root, query, cb) -> "".equals(customerEmail) ? cb.conjunction() : cb.equal(root.get("customerEmail"), customerEmail))
				.and((root, query, cb) -> "".equals(registeredAddress) ? cb.conjunction()
						: cb.equal(root.get("registeredAddress"), registeredAddress))
				.and((root, query, cb) -> customerTypeId == 0 ? cb.conjunction()
						: cb.equal(root.get("customerTypeEntity").get("customerTypeId"), customerTypeId));
	}

	public HashMap<String, Object> findCustomersWithFilters(String customerBDID, String customerName, String customerEmail, String registeredAddress,
			int countryId, int stateId, int cityId, int localityId, String pincode, int customerTypeId, Pageable pageable) {
		HashMap<String, Object> job = new HashMap<>();
		Specification<CustomerEntity> specs = customerFilterSpecification(customerBDID, customerName, customerEmail, registeredAddress, countryId,
				stateId, cityId, localityId, pincode, customerTypeId);
		long count = repoCustomer.count(specs);
		job.put("count", count);
		if (count > 0) {
			job.put("list", repoCustomer.findAll(specs, pageable).getContent());
		}
		return job;
	}

	public List<CustomerTypeEntity> getAllCustomerType() {
		return repoCustomerType.findAll();
	}

	public CustomerEntity getCustomerById(boolean getLazyObj, int customerId) {
		CustomerEntity cust = repoCustomer.findById(customerId)
				.orElseThrow(() -> new UsernameNotFoundException(messageResource.getMessage("customer.absent", null, null, null)));
		if (getLazyObj) {
			Hibernate.initialize(cust.getProjectEntityList());
			Hibernate.initialize(cust.getCustomerTypeEntity());
		}
		return cust;
	}

}
