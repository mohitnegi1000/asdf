package com.gspl.customerregistration.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gspl.customerregistration.entity.CountryEntity;
import com.gspl.customerregistration.entity.CustomerEntity;
import com.gspl.customerregistration.entity.CustomerTypeEntity;
import com.gspl.customerregistration.exception.ValidationException;
import com.gspl.customerregistration.service.CustomerService;
import com.gspl.customerregistration.service.GeographicalLocationService;
import com.gspl.customerregistration.utility.Constants;

import lombok.extern.log4j.Log4j2;

@Log4j2
@RestController
@RequestMapping("/Customer")
public class CustomerRegistrationController {

	@Autowired
	private CustomerService customerService;

	@Autowired
	private GeographicalLocationService geographicalLocationService;

	@Autowired
	@Qualifier("messages")
	private MessageSource messageResource;

	@GetMapping("/searchCustomer")
	public ResponseEntity<Map<String, Object>> searchCustomer() {
		List<CountryEntity> countries = geographicalLocationService.getAllCountries();
		List<CustomerTypeEntity> customers = customerService.getAllCustomerType();
		Map<String, Object> response = new HashMap<>();
		if (countries != null && customers != null) {
			response.put("countries", countries);
			response.put("customers", customers);
			return ResponseEntity.ok(response);
		}
		return ResponseEntity.notFound().build();
	}

	@GetMapping("/listCustomer")
	public ResponseEntity<HashMap<String, Object>> listCustomer(@RequestParam(required = false, defaultValue = "") String bdid,
			@RequestParam(required = false, defaultValue = "") String customerName,
			@RequestParam(required = false, defaultValue = "") String customerEmail,
			@RequestParam(required = false, defaultValue = "") String registeredAddress,
			@RequestParam(required = false, defaultValue = "0") int countryId, @RequestParam(required = false, defaultValue = "0") int stateId,
			@RequestParam(required = false, defaultValue = "0") int cityId, @RequestParam(required = false, defaultValue = "0") int localityId,
			@RequestParam(required = false, defaultValue = "0") String pincode,
			@RequestParam(required = false, defaultValue = "0") int customerTypeId,
			@PageableDefault(size = Constants.PAGE_SIZE, page = 0, sort = "customerId", direction = Direction.DESC) Pageable pageable) {

		HashMap<String, Object> customers = customerService.findCustomersWithFilters(bdid, customerName, customerEmail, registeredAddress, countryId,
				stateId, cityId, localityId, pincode, customerTypeId, pageable);

		return ResponseEntity.ok(customers);
	}

	@PostMapping("/listCustomerBody")
	public ResponseEntity<HashMap<String, Object>> listCustomerBody(@RequestBody(required = false) CustomerEntity customerEntity,
			@PageableDefault(size = Constants.PAGE_SIZE, page = 0, sort = "customerId", direction = Direction.DESC) Pageable pageable) {

		if (customerEntity == null) {
			customerEntity = new CustomerEntity();
		}

		HashMap<String, Object> customers = customerService.findCustomersWithFilters(String.valueOf(customerEntity.getCustomerBDID()),
				customerEntity.getCustomerName(), customerEntity.getCustomerEmail(), customerEntity.getRegisteredAddress(),
				customerEntity.getLocalityEntity().getCityEntity().getStateEntity().getCountryEntity().getCountryId(),
				customerEntity.getLocalityEntity().getCityEntity().getStateEntity().getStateId(),
				customerEntity.getLocalityEntity().getCityEntity().getCityId(), customerEntity.getLocalityEntity().getLocalityId(),
				customerEntity.getLocalityEntity().getPincode(), customerEntity.getCustomerTypeEntity().getCustomerTypeId(), pageable);

		return ResponseEntity.ok(customers);
	}

	@PostMapping("/listCustomerJSONBody")
	public ResponseEntity<HashMap<String, Object>> listCustomerJSONBody(@RequestBody(required = false) HashMap<String, Object> requestBody,
			@PageableDefault(size = Constants.PAGE_SIZE, page = 0, sort = "customerId", direction = Direction.DESC) Pageable pageable) {
		String customerBDID = (String) requestBody.getOrDefault("customerBDID", "");
		String customerName = (String) requestBody.getOrDefault("customerName", "");
		String customerEmail = (String) requestBody.getOrDefault("customerEmail", "");
		String registeredAddress = (String) requestBody.getOrDefault("registeredAddress", "");
		String pincode = (String) requestBody.getOrDefault("pincode", "");
		int stateId = (int) requestBody.getOrDefault("stateId", 0);
		int countryId = (int) requestBody.getOrDefault("countryId", 0);
		int cityId = (int) requestBody.getOrDefault("cityId", 0);
		int localityId = (int) requestBody.getOrDefault("localityId", 0);
		int customerTypeId = (int) requestBody.getOrDefault("customerTypeId", 0);

		HashMap<String, Object> customers = customerService.findCustomersWithFilters(customerBDID, customerName, customerEmail, registeredAddress,
				countryId, stateId, cityId, localityId, pincode, customerTypeId, pageable);

		return ResponseEntity.ok(customers);
	}

	@GetMapping("/getCustomerById")
	public CustomerEntity getCustomerById(@RequestParam(defaultValue = "false", required = false) boolean getLazyObj, @RequestParam int customerId) {
		return customerService.getCustomerById(getLazyObj, customerId);
	}

	@PostMapping("/createOrUpdateCustomer")
	public ResponseEntity<String> createOrUpdateCustomers(@RequestBody CustomerEntity customer) throws Exception {
		JSONArray errors = new JSONArray();
		JSONObject job = new JSONObject();
		try {
			int id = customerService.createOrUpdateEntity(customer, errors);
			job.put("ID", id);
			return ResponseEntity.status(HttpStatus.CREATED).body(job.toString());
		} catch (Exception e) {
			log.error("error : ", e);

			if (e instanceof DataIntegrityViolationException) {
				throw e;
			}

			if (!(e instanceof ValidationException)) {
				errors.put(e.getLocalizedMessage());
			}
			job.put("errors", errors);

			return ResponseEntity.status(HttpStatus.PARTIAL_CONTENT).body(job.toString());
		}
	}

}
