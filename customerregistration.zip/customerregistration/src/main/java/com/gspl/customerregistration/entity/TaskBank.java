package com.gspl.customerregistration.entity;

import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;

//@Entity
@Getter
@Setter
//@Table()
public class TaskBank {

	private String serviceType;
	@Id
	private int taskId;

	private int taskGroupId;

	private int activityTemplateId;

	private String taskDescription;

	private String taskInputType;

	private String taskInputData;

	private String inputDataUOM;

	private String productCategory;

	private String itemGenre;

	private int itemCode;

	private String siteType;
}
