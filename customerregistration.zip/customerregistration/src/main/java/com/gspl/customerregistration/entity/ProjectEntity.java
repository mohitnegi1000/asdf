package com.gspl.customerregistration.entity;

import java.util.Date;
import java.util.Set;

import org.hibernate.annotations.ColumnDefault;
import org.springframework.data.jpa.domain.Specification;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "cmsProject")
public class ProjectEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public long projectId;

	@ColumnDefault("''")
	private String contractNo;

	@ColumnDefault("''")
	private String projectName;

	@ColumnDefault("''")
	private String projectCode;

	private short rfpType;
//	Constants.RFPType;

	private short revenueModel;
//	Constants.revenueModel;

	@Column(name = "initiation_date", columnDefinition = "DATE", insertable = false, nullable = false)
	@ColumnDefault("'1900-01-01'")
	Date initiationDate;

	private short coverage;

	@Column(name = "wty_time_period", columnDefinition = "DATE", insertable = false, nullable = false)
	@ColumnDefault("'1900-01-01'")
	Date wtyTimePeriod;

	@Column(name = "amc_time_period", columnDefinition = "DATE", insertable = false, nullable = false)
	@ColumnDefault("'1900-01-01'")
	Date amcTimePeriod;

	private short wtyServiceCoverage;

	private short amcServiceCoverage;

	@OneToMany(mappedBy = "projectEntity", fetch = FetchType.EAGER)
//	@JsonManagedReference
	private Set<InstallationTaskList> installationTaskList;

	private double otvCharges;

	@Column(name = "valid_till_date", columnDefinition = "DATE", insertable = false, nullable = false)
	@ColumnDefault("'1900-01-01'")
	Date validTillDate;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "customer_id", nullable = false)
	@JsonBackReference
	private CustomerEntity customerEntity;

	public static Specification<ProjectEntity> specsEqual() {
		return (root, query, cb) -> cb.notEqual(root.get("projectId"), "0");
	}
}
