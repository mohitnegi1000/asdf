package com.gspl.customerregistration.security;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.jdbc.BadSqlGrammarException;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.servlet.HandlerExceptionResolver;

import com.gspl.customerregistration.entity.AuthorizationEntity;
import com.gspl.customerregistration.repository.RepoAuthorization;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.log4j.Log4j2;

@Log4j2
@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class SQLSecurityFilter extends OncePerRequestFilter {

	@Autowired
	@Qualifier("handlerExceptionResolver")
	private HandlerExceptionResolver exceptionResolver;

	@Autowired
	private RepoAuthorization repoAuth;

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
			throws ServletException, IOException {

		Enumeration<String> parameterNames = request.getParameterNames();
		while (parameterNames.hasMoreElements()) {
			String paramName = parameterNames.nextElement();
			String[] paramValues = request.getParameterValues(paramName);
			for (String paramValue : paramValues) {
				if (!checkSqlInjections(paramValue)) {
					log.error("SQLINJECTION->PARAM : " + paramValue);
					exceptionResolver.resolveException(request, response, null, new BadSqlGrammarException("SQLINJECTION", "INJECTIONSQL", null));
					return;
				}
			}
		}

//		Enumeration<String> headerNames = request.getHeaderNames();
//		while (headerNames.hasMoreElements()) {
//			String headerName = headerNames.nextElement();
//			if (!checkSqlInjections(request.getHeader(headerName))) {
//				log.error("SQLINJECTION->HEADER : " + request.getHeader(headerName));
//				request.getRequestDispatcher("/unAuthorizedRequestData").forward(request, response);
//				return;
//			}
//		}

		MultiReadHttpServletRequest req = new MultiReadHttpServletRequest(request);

		try (BufferedReader reader = req.getReader()) {
			StringBuilder sb = new StringBuilder();
			String line;
			while ((line = reader.readLine()) != null) {
				sb.append(line);
			}

			if (!sb.isEmpty()) {
				JSONObject job = new JSONObject(sb.toString());
				if (requestBodyChecker(job)) {
					exceptionResolver.resolveException(request, response, null, new BadSqlGrammarException("SQLINJECTION", "INJECTIONSQL", null));
					return;
				}
			}
		}

		chain.doFilter(req, response);

	}

	boolean checkSqlInjections(String str) {
		if ("".equals(str)) {
			return true;
		}
		if (str.contains("\'") || str.contains("\"") || str.contains("--") || str.contains(";") || str.contains("<") || str.contains(">")
				|| str.contains("../../")) {
			return false;
		}
		return true;
	}

	boolean requestBodyChecker(JSONObject job) {
		for (String key : job.keySet()) {
			if (!checkSqlInjections(key)) {
				log.error("SQLINJECTION->BODY KEY : " + key);
				return true;
			}
			if (job.get(key) instanceof JSONObject) {
				requestBodyChecker(job.getJSONObject(key));
			} else if (job.get(key) instanceof JSONArray) {
				for (Object obj : job.getJSONArray(key)) {
					if (obj instanceof String) {
						if (!checkSqlInjections((String) obj)) {
							log.error("SQLINJECTION->BODY KEY : " + key);
							return true;
						}
					} else if (obj instanceof Integer) {
						if (!checkSqlInjections(String.valueOf(obj))) {
							log.error("SQLINJECTION->BODY KEY : " + key);
							return true;
						}
					} else {
						requestBodyChecker((JSONObject) obj);
					}
				}
			} else if (!checkSqlInjections(String.valueOf(job.get(key)))) {
				log.error("SQLINJECTION->BODY VALUE: " + key + "=" + job.getString(key));
				return true;
			}
		}
		return false;
	}

	@Bean(name = "authMapping")
	Map<String, Integer> authMapping() {
		Map<String, Integer> jon = repoAuth.getAuthObject().stream()
				.collect(Collectors.toMap((Function<? super AuthorizationEntity, ? extends String>) AuthorizationEntity::getAuthorizationMapping,
						(Function<? super AuthorizationEntity, ? extends Integer>) AuthorizationEntity::getAuthorizationId));
		return jon;
	}

	@Bean(name = "authMappingDefaults")
	Map<String, Integer> authMappingDefaults() {
		Map<String, Integer> jon = repoAuth.getAuthObjectDefaults().stream()
				.collect(Collectors.toMap((Function<? super AuthorizationEntity, ? extends String>) AuthorizationEntity::getAuthorizationMapping,
						(Function<? super AuthorizationEntity, ? extends Integer>) AuthorizationEntity::getAuthorizationId));
		return jon;
	}
}
