package com.gspl.customerregistration.entity;

import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import lombok.Getter;
import lombok.Setter;

//@Entity
@Getter
@Setter
//@JsonIgnoreProperties({ "coverage" })
//@Table(name = "cms_project_svc_cvg_relation")
public class ProjectServiceCoverageRelation {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public long relId;

	@ManyToOne(fetch = FetchType.LAZY)
	ServiceCoverageEntity serviceCoverageEntity;

	@ManyToOne(fetch = FetchType.EAGER)
	ProjectEntity projectEntity;

}
