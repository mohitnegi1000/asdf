package com.gspl.customerregistration.utility;

import java.util.Date;
import java.util.Random;

import org.springframework.stereotype.Component;

@Component
public class CommonUtilities {

	public boolean validatePassword(String str) {
		boolean noPresent = false;
		boolean smallAlphaPresent = false;
		boolean bigAlphaPresent = false;
		boolean specialCharPresent = false;
		boolean isValidPassword = false;

		if (str.length() > 8 || str.length() < 12) {
			if (containsSpecialCharacter(str)) {
				specialCharPresent = true;
			}
			for (char i = 0; i < str.length(); i++) {
				char chr = str.charAt(i);
				if (chr >= '0' && chr <= '9') {
					noPresent = true;
					break;
				}
			}
			for (char i = 0; i < str.length(); i++) {
				char chr = str.charAt(i);
				if (chr >= 'a' && chr <= 'z') {
					smallAlphaPresent = true;
					break;
				}
			}
			for (char i = 0; i < str.length(); i++) {
				char chr = str.charAt(i);
				if (chr >= 'A' && chr <= 'Z') {
					bigAlphaPresent = true;
					break;
				}
			}
		}
		if (noPresent && smallAlphaPresent && bigAlphaPresent && specialCharPresent) {
			isValidPassword = true;
		}
		return isValidPassword;
	}

	private boolean containsSpecialCharacter(String str) {
		String specialChars = "!@#$%^&*()-_=+[{]};:'\",<.>/?\\|";
		for (char i = 0; i < str.length(); i++) {
			if (specialChars.indexOf(str.charAt(i)) != -1) {
				return true;
			}
		}
		return false;
	}

	public boolean validatePasswordReg(String str) {
		String regex = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*()\\-_=+\\[\\]{};:'\",<.>/?\\\\|]).{8,12}$";
//					"^(?=.*[0-9]) 									 0-9 should be there atleast once
//					(?=.*[a-z])										 a to z small letter should be there atleast once
//					(?=.*[A-Z])										 A to Z capital letter should be there atleast once
//					(?=.*[!@#$%^&*()\\-_=+\\[\\]{};:'\",<.>/?\\\\|]) anthing from here should be there atleast once
//					.{8,12}$"; 										 should be limited from 8 to 12 char only
		return str.matches(regex);
	}

	public boolean validateEmailReg(String str) {
		return str.matches("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}");
	}

//	private static byte[] operation(byte[] data, int mode) throws Exception {
//		byte[] keyValue = "abcdefghijklmnop".getBytes();
//		Key key = new SecretKeySpec(keyValue, "AES");
//		Cipher c = Cipher.getInstance("AES/ECB/PKCS5Padding");
//		c.init(mode, key);
//		return c.doFinal(data);

//		try {
//			byte[] jwt = "3cfa76ef14937c1c0ea519f8fc057a80fcd04a7420f8e8bcd0a7567c272e007b".getBytes();
//			System.out.println("Plain Text : " + new String(jwt));
//			byte[] arrayEnc = operation(jwt, Cipher.ENCRYPT_MODE);
//			System.out.println("Encrypted  vybn thb tt\Text : { " + (new String(arrayEnc)) + " }");
//			byte[] arrayDec = operation(arrayEnc, Cipher.DECRYPT_MODE);
//			System.out.println("Decrypted Text : { " + new String(arrayDec) + " }");
//			byte[] ajsdb = { 80, 112, -94, 9, 77, 125, -20, -124, -116, 106, -116, 83, -98, 62, -105, 47, 5, 16, -71, -65, 56, 40, -61, 125, -123, 7,
//					125, -18, 11, 12, 89, 24, -97, -117, -43, -7, -53, 71, -97, -110, -91, -92, -77, 75, 27, 70, 7, -46, 1, 78, -98, 47, -34, -93, 42,
//					-13, -110, 26, -46, -66, -22, 16, 57, 83, -114, 100, -50, -121, 63, 23, 77, -69, 36, 35, -4, -40, 20, 88, 14, 21 };
//			System.out.println(new String(operation(ajsdb, Cipher.DECRYPT_MODE)));
//		} catch (Exception e) { gn g vtf gtd
//			e.printStackTrace();
//		}
//		 select concat(md5(random()::text) , md5(random()::text));

//		begin;
//
//		CREATE FUNCTION jwt()
//		RETURNS varchar AS $$
//		BEGIN
//		    RETURN '3cfa76ef14937c1c0ea519f8fc057a80fcd04a7420f8e8bcd0a7567c272e007b';
//		END; $$
//		LANGUAGE plpgsql;
//
//		select jwt();

//		rollback;

//	}

	public String[] simplifiedGetGen(double nCharsDbl, int nTimesDbl, Random randInt) {
		Date now = new Date();

		String preUseChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		boolean running = true, allowDuplicatePasswords = false;
		String excChars = "";
		String useChars = "";
		String generatedPwords = "";
		int pwordCount = 0;
		for (int i = 0; i < preUseChars.length(); i++) {
			if (!excChars.contains(String.valueOf(preUseChars.charAt(i)))) {
				useChars += preUseChars.charAt(i);
			}
		}
		String[] passwords = new String[nTimesDbl];
		for (int i = 0; i < nTimesDbl && running; i++) {

			// int thisone = i + 1;
			// this.onProgressUpdate();

			String thisPword;
			do {
				thisPword = "";
				for (int j = 0; j < nCharsDbl && running; j++) {
					randInt.setSeed(Math.round(i * nCharsDbl * j + now.getTime() + randInt.nextInt()));
					thisPword += useChars.charAt(randInt.nextInt(useChars.length()));
				}
			} while (generatedPwords.contains(thisPword + "\n") && !allowDuplicatePasswords && running);
			generatedPwords += thisPword + "\n";
			pwordCount++;
			passwords[pwordCount - 1] = thisPword;
		}
		return passwords;
	}

}
