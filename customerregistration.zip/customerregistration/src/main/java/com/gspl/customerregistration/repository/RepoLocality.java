package com.gspl.customerregistration.repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.gspl.customerregistration.entity.LocalityEntity;

public interface RepoLocality extends JpaRepository<LocalityEntity, Integer>, CrudRepository<LocalityEntity, Integer> {

	Optional<LocalityEntity> findTopByPincode(String pincode);

	List<LocalityEntity> findByPincode(String pincode);

	List<LocalityEntity> findByCityEntityCityId(int cityid);

	boolean existsByPincode(String pinCode);

	@Query("SELECT new LocalityEntity(l.localityName as localityName, l.pincode as pincode) FROM LocalityEntity l")
	List<LocalityEntity> findLocalityNameAndPincode();

	@Query("SELECT new Map(l.localityName as localityName, l.pincode as pincode) FROM LocalityEntity l")
	List<Map<String, String>> findLocalityNameAndPincodeMap();

//	@Query(":query")
//	List<String> checkQuery(String query);
}
