package com.gspl.customerregistration.entity;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;

//@Entity
@Getter
@Setter
//@Table(name = "svc_cvg")
public class ServiceCoverageEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int id;

	private boolean isWarrantyAMC;

	private short svgCvgType;

	private String svgCvgname;

	private String svgCvgcode;

	private String svgCvgpercentage;
}
