package com.gspl.customerregistration.entity;

import java.util.Set;

import org.hibernate.annotations.ColumnDefault;
import org.springframework.data.jpa.domain.Specification;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.criteria.JoinType;
import lombok.Getter;
import lombok.Setter;

@Entity
@Setter
@Getter
@Table(name = "cmsCustomer")
public class CustomerEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int customerId;

	@Column(unique = true, nullable = false)
	private int customerBDID;

	@ColumnDefault("''")
	private String customerName = "";

	@ColumnDefault("''")
	@Column(unique = true, nullable = false)
	private String customerEmail = "";

	private String registeredAddress = "";

	@ManyToOne(fetch = FetchType.EAGER, optional = false)
	@JoinColumn(name = "locality_id")
	private LocalityEntity localityEntity = new LocalityEntity();

	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "customer_type_id")
	private CustomerTypeEntity customerTypeEntity = new CustomerTypeEntity();

	@OneToMany(mappedBy = "customerEntity", fetch = FetchType.LAZY)
	private Set<ProjectEntity> projectEntityList;

	public static Specification<CustomerEntity> specsEqual() {
		return (root, query, cb) -> {
			if (Long.class != query.getResultType()) {
				root.fetch("customerTypeEntity", JoinType.INNER);
			}
			return cb.notEqual(root.get("customerId"), "0");
		};
	}

}
