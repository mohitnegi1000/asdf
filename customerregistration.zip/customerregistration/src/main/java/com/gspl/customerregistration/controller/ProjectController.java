package com.gspl.customerregistration.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gspl.customerregistration.entity.ProjectEntity;
import com.gspl.customerregistration.exception.ValidationException;
import com.gspl.customerregistration.repository.RepoProject;
import com.gspl.customerregistration.service.ProjectService;
import com.gspl.customerregistration.utility.Constants;

import lombok.extern.log4j.Log4j2;

@Log4j2
@RestController
@RequestMapping("/Project")
public class ProjectController {

	@Autowired
	ProjectService projectService;

	@Autowired
	RepoProject repoProject;

	@GetMapping("/searchProject")
	public ResponseEntity<Map<String, Object>> searchProject() {
		Map<String, Object> projects = projectService.getAllProjects();

		return ResponseEntity.ok(projects);

	}

	@PostMapping("/listProjectsBody")
	public ResponseEntity<Map<String, Object>> listProjectsBody(@RequestBody Map<String, Object> map,
			@PageableDefault(size = Constants.PAGE_SIZE, page = 0, sort = "projectId", direction = Direction.DESC) Pageable pageable) {
		int customerId = 0;

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
//		DateFormat df = DateFormat.getDateInstance(Locale.Category.FORMAT);
		mapper.setDateFormat(new SimpleDateFormat("dd-MM-yyyy"));

		ProjectEntity projectEntity = mapper.convertValue(map.get("projectEntity"), ProjectEntity.class);

		Date initiationDateTo = mapper.convertValue(map.get("initiationDateTo"), Date.class);
		Date initiationDateFrom = mapper.convertValue(map.get("initiationDateFrom"), Date.class);
		Date wtyTimePeriodTo = mapper.convertValue(map.get("wtyTimePeriodTo"), Date.class);
		Date wtyTimePeriodFrom = mapper.convertValue(map.get("wtyTimePeriodFrom"), Date.class);
		Date amcTimePeriodTo = mapper.convertValue(map.get("amcTimePeriodTo"), Date.class);
		Date amcTimePeriodFrom = mapper.convertValue(map.get("amcTimePeriodFrom"), Date.class);
		Date validTillDateTo = mapper.convertValue(map.get("validTillDateTo"), Date.class);
		Date validTillDateFrom = mapper.convertValue(map.get("validTillDateFrom"), Date.class);

		if (projectEntity != null && projectEntity.getCustomerEntity() != null) {
			customerId = projectEntity.getCustomerEntity().getCustomerId();
		}
		Map<String, Object> projects = projectService.findProjectsWithFilters(projectEntity.getContractNo(), projectEntity.getProjectName(),
				projectEntity.getProjectCode(), projectEntity.getRfpType(), projectEntity.getRevenueModel(), projectEntity.getCoverage(),
				projectEntity.getWtyServiceCoverage(), projectEntity.getAmcServiceCoverage(), projectEntity.getOtvCharges(), initiationDateTo,
				initiationDateFrom, wtyTimePeriodTo, wtyTimePeriodFrom, amcTimePeriodTo, amcTimePeriodFrom, validTillDateTo, validTillDateFrom,
				customerId, pageable);

		return ResponseEntity.ok(projects);
	}

	@PostMapping("/listProjects")
	public ResponseEntity<Map<String, Object>> listProjects(@RequestParam(required = false, defaultValue = "01-01-1900") Date initiationDateTo,
			@RequestParam(required = false, defaultValue = "01-01-1900") Date initiationDateFrom,
			@RequestParam(required = false, defaultValue = "01-01-1900") Date wtyTimePeriodTo,
			@RequestParam(required = false, defaultValue = "01-01-1900") Date wtyTimePeriodFrom,
			@RequestParam(required = false, defaultValue = "01-01-1900") Date amcTimePeriodTo,
			@RequestParam(required = false, defaultValue = "01-01-1900") Date amcTimePeriodFrom,
			@RequestParam(required = false, defaultValue = "01-01-1900") Date validTillDateTo,
			@RequestParam(required = false, defaultValue = "01-01-1900") Date validTillDateFrom,
			@RequestBody(required = false) ProjectEntity projectEntity,
			@PageableDefault(size = Constants.PAGE_SIZE, page = 0, sort = "projectId", direction = Direction.DESC) Pageable pageable) {
		int customerId = 0;
		if (projectEntity != null && projectEntity.getCustomerEntity() != null) {
			customerId = projectEntity.getCustomerEntity().getCustomerId();
		}
		Map<String, Object> projects = projectService.findProjectsWithFilters(projectEntity.getContractNo(), projectEntity.getProjectName(),
				projectEntity.getProjectCode(), projectEntity.getRfpType(), projectEntity.getRevenueModel(), projectEntity.getCoverage(),
				projectEntity.getWtyServiceCoverage(), projectEntity.getAmcServiceCoverage(), projectEntity.getOtvCharges(), initiationDateTo,
				initiationDateFrom, wtyTimePeriodTo, wtyTimePeriodFrom, amcTimePeriodTo, amcTimePeriodFrom, validTillDateTo, validTillDateFrom,
				customerId, pageable);

		return ResponseEntity.ok(projects);
	}

	@PostMapping("/createOrUpdateProject")
	public ResponseEntity<String> createOrUpdateCustomers(@RequestBody ProjectEntity project) {
		JSONArray errors = new JSONArray();
		JSONObject job = new JSONObject();
		try {
			long id = projectService.createOrUpdateProject(project, errors);
			job.put("ID", id);
			return ResponseEntity.status(HttpStatus.CREATED).body(job.toString());

		} catch (Exception e) {
			log.error("error : ", e);
			if (!(e instanceof ValidationException)) {
				errors.put(e.getLocalizedMessage());
			}
			job.put("errors", errors);
			return ResponseEntity.status(HttpStatus.PARTIAL_CONTENT).body(job.toString());
		}

	}
}
