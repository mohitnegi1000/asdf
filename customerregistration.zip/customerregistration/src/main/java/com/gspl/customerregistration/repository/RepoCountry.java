package com.gspl.customerregistration.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import com.gspl.customerregistration.entity.CountryEntity;

public interface RepoCountry extends JpaRepository<CountryEntity, Integer>, CrudRepository<CountryEntity, Integer> {

	Optional<CountryEntity> findTopByCountryCode(String countryCode);

	boolean existsByCountryCode(String countryCode);

}
