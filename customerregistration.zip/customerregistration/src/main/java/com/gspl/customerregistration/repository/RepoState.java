package com.gspl.customerregistration.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import com.gspl.customerregistration.entity.StateEntity;

public interface RepoState extends JpaRepository<StateEntity, Integer>, CrudRepository<StateEntity, Integer> {

	List<StateEntity> findByCountryEntityCountryId(int countryId);

	Optional<StateEntity> findTopByStateCode(String stateCode);

	boolean existsByStateCode(String stateCode);
}
