package com.gspl.customerregistration.entity;

import org.hibernate.annotations.ColumnDefault;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "cmsState")
public class StateEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int stateId;

	private String stateName = "";
	private String stateCode = "";

	@ManyToOne(fetch = FetchType.EAGER)
	@ColumnDefault("'0'")
	@JoinColumn(name = "country_id")
	public CountryEntity countryEntity;

}
