package com.gspl.customerregistration.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "cmsCustomerType")
public class CustomerTypeEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int customerTypeId;

	private String customerTypeName = "";
	private String customerTypeCode = "";
}
