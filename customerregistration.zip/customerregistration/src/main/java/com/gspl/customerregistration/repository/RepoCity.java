package com.gspl.customerregistration.repository;

import java.util.List;
//import java.util.Optional;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import com.gspl.customerregistration.entity.CityEntity;

public interface RepoCity extends JpaRepository<CityEntity, Integer>, CrudRepository<CityEntity, Integer> {

	List<CityEntity> findByStateEntityStateId(int stateId);

	Optional<CityEntity> findTopByCityCode(String cityCode);

	boolean existsByCityCode(String cityCode);
}
