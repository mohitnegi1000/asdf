package com.gspl.customerregistration.entity;

import org.hibernate.annotations.ColumnDefault;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "cmsAuthorizationEntity")
public class AuthorizationEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int authorizationId;

	private String authorizationMS;
	private String authorizationName;
	private String authorizationMapping;

	@ColumnDefault("false")
	private boolean isMenuItem;

	@ColumnDefault("-1")
	private int parentId;

	@ColumnDefault("''")
	private String icon = "";

	@ColumnDefault("false")
	private boolean isDefault;
}
