package com.gspl.customerregistration.utility;

import java.util.Date;

public final class Constants {

	public static final int PAGE_SIZE = 20;

	public static final Date DATE_DEFAULT = new Date(0, 0, 1);
	public static final String DEFAULT_DATE = "Mon Jan 01 00:00:00 IST 1900";

	public static final class AuthorizationMS {
		public static final String AUTHENTICATION = "AuthenticationService";
		public static final String CUSTOMER = "CustomerRegistration";
	}

	public static class MailSmsType {
		public static final int INACTIVE = 0;
		public static final int MAIL = 1;
		public static final int SMS = 2;
	}

	public static class CoverageType {
		public static final int MACHINE = 1;
		public static final int PERIPHERALS = 2;
		public static final int OTHERS = 3;
	}

	public static class SvgCvgType {
		public static final int PART = 1;
		public static final int LABOUR = 2;
	}

	public static final class CustomerTypeCode {
		public static final String PSU = "PSU";
		public static final String PUBLIC = "PUB";
		public static final String PRIVATE = "PRI";
	}

	public static final class RFPType {
		public static final int INSTALLATION = 1;
		public static final int SLM = 2;
		public static final int INSTALLATION_SLM = 3;
	}

	public static final class RevenueModel {
		public static final int AMC = 1;
		public static final int ON_DEMAND = 2;
		public static final int WARRANTY = 3;
	}

	public static class MailEventId {
		public static final int FORGOT_PASSWORD = 1;
		public static final int FORGOT_PASSWORD_OTP = 2;
	}

	private Constants() {

	}
}
