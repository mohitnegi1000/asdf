package com.gspl.customerregistration.service;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gspl.customerregistration.entity.ProjectEntity;
import com.gspl.customerregistration.exception.ValidationException;
import com.gspl.customerregistration.repository.RepoCustomer;
import com.gspl.customerregistration.repository.RepoProject;
import com.gspl.customerregistration.utility.Constants;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Service
public class ProjectService {

	@Autowired
	RepoCustomer repoCustomer;
	@Autowired
	RepoProject repoProject;

	public Map<String, Object> getAllProjects() {

		HashMap<String, Object> map = new HashMap<>();
		ArrayList<HashMap<String, Object>> arr = new ArrayList<>();

		Field[] fields = Constants.RFPType.class.getDeclaredFields();
		for (Field field : fields) {
			try {
				HashMap<String, Object> hmx = new HashMap<>() {
					{
						put("RFPTypeName", field.getName().replace('_', ' '));
						put("RFPTypeValue", field.getInt(null));
					}
				};
				arr.add(hmx);
			} catch (IllegalArgumentException | IllegalAccessException e) {
				log.error("Error : ", e);
			}
		}

		map.put("RFPType", arr);

		arr = new ArrayList<>();
		fields = Constants.RevenueModel.class.getDeclaredFields();
		for (Field field : fields) {
			try {
				HashMap<String, Object> hmx = new HashMap<>() {
					{
						put("RevenueModelName", field.getName().replace('_', ' '));
						put("RevenueModelValue", field.getInt(null));
					}
				};
				arr.add(hmx);
			} catch (IllegalArgumentException | IllegalAccessException e) {
				log.error("Error : ", e);
			}
		}

		map.put("RevenueModel", arr);

//		map.put("customerList", repoCustomer.findAll());
		return map;

	}

	@Transactional
	public long createOrUpdateProject(ProjectEntity project, JSONArray errors) throws Exception {
		if (project.getContractNo() == null || project.getContractNo().isEmpty()) {
			errors.put("Contract No. Empty");
		}
		if ("".equals(project.getProjectName())) {
			errors.put("ProjectName is empty");
		}

		if (!errors.isEmpty()) {
			throw new ValidationException();
		}

		if (project.getProjectId() == 0 || repoProject.existsById((int) project.getProjectId())) {
			return repoProject.save(project).getProjectId();
		}
		return 0;
	}

	public Map<String, Object> findProjectsWithFilters(String contractNo, String projectName, String projectCode, short rfpType, short revenueModel,
			short coverage, short wtyServiceCoverage, short amcServiceCoverage, double otvCharges, Date initiationDateTo, Date initiationDateFrom,
			Date wtyTimePeriodTo, Date wtyTimePeriodFrom, Date amcTimePeriodTo, Date amcTimePeriodFrom, Date validTillDateTo, Date validTillDateFrom,
			int customerId, Pageable pageable) {
		Specification<ProjectEntity> ssSpecification = Specification.where(ProjectEntity.specsEqual())
				.and((root, query, cb) -> contractNo == null || "0".equals(contractNo) ? cb.conjunction()
						: cb.equal(root.get("contractNo"), contractNo))
				.and((root, query, cb) -> projectName == null || "0".equals(projectName) ? cb.conjunction()
						: cb.equal(root.get("projectName"), projectName))
				.and((root, query, cb) -> projectCode == null || "0".equals(projectCode) ? cb.conjunction()
						: cb.equal(root.get("projectCode"), projectCode))
				.and((root, query, cb) -> customerId == 0 ? cb.conjunction() : cb.equal(root.get("customerEntity").get("customerId"), customerId))
				.and((root, query, cb) -> rfpType == 0 ? cb.conjunction() : cb.equal(root.get("rfpType"), rfpType))
				.and((root, query, cb) -> revenueModel == 0 ? cb.conjunction() : cb.equal(root.get("revenueModel"), revenueModel))
				.and((root, query, cb) -> coverage == 0 ? cb.conjunction() : cb.equal(root.get("coverage"), coverage))
				.and((root, query, cb) -> wtyServiceCoverage == 0 ? cb.conjunction() : cb.equal(root.get("wtyServiceCoverage"), wtyServiceCoverage))
				.and((root, query, cb) -> amcServiceCoverage == 0 ? cb.conjunction() : cb.equal(root.get("amcServiceCoverage"), amcServiceCoverage))
				.and((root, query, cb) -> otvCharges == 0 ? cb.conjunction() : cb.equal(root.get("otvCharges"), otvCharges))
				.and((root, query, cb) -> initiationDateFrom == null || Constants.DATE_DEFAULT.equals(initiationDateFrom) ? cb.conjunction()
						: cb.greaterThanOrEqualTo(root.get("initiationDate"), initiationDateFrom))
				.and((root, query, cb) -> initiationDateTo == null || Constants.DATE_DEFAULT.equals(initiationDateTo) ? cb.conjunction()
						: cb.lessThanOrEqualTo(root.get("initiationDate"), initiationDateTo))
				.and((root, query, cb) -> wtyTimePeriodFrom == null || Constants.DATE_DEFAULT.equals(wtyTimePeriodFrom) ? cb.conjunction()
						: cb.greaterThanOrEqualTo(root.get("wtyTimePeriod"), wtyTimePeriodFrom))
				.and((root, query, cb) -> wtyTimePeriodTo == null || Constants.DATE_DEFAULT.equals(wtyTimePeriodTo) ? cb.conjunction()
						: cb.lessThanOrEqualTo(root.get("wtyTimePeriod"), wtyTimePeriodTo))
				.and((root, query, cb) -> amcTimePeriodFrom == null || Constants.DATE_DEFAULT.equals(amcTimePeriodFrom) ? cb.conjunction()
						: cb.greaterThanOrEqualTo(root.get("amcTimePeriod"), amcTimePeriodFrom))
				.and((root, query, cb) -> amcTimePeriodTo == null || Constants.DATE_DEFAULT.equals(amcTimePeriodTo) ? cb.conjunction()
						: cb.lessThanOrEqualTo(root.get("amcTimePeriod"), amcTimePeriodTo))
				.and((root, query, cb) -> validTillDateFrom == null || Constants.DATE_DEFAULT.equals(validTillDateFrom) ? cb.conjunction()
						: cb.greaterThanOrEqualTo(root.get("validTillDate"), validTillDateFrom))
				.and((root, query, cb) -> validTillDateTo == null || Constants.DATE_DEFAULT.equals(validTillDateTo) ? cb.conjunction()
						: cb.lessThanOrEqualTo(root.get("validTillDate"), validTillDateTo));

		HashMap<String, Object> map = new HashMap<>();
		long count = repoProject.count(ssSpecification);

		if (count > 0) {
			map.put("count", count);
			map.put("list", repoProject.findAll(ssSpecification, pageable).getContent());
		} else {
			map.put("count", count);
		}
		return map;
	}
}
