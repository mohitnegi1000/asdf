package com.gspl.customerregistration.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

import com.gspl.customerregistration.entity.CityEntity;
import com.gspl.customerregistration.entity.CountryEntity;
import com.gspl.customerregistration.entity.LocalityEntity;
import com.gspl.customerregistration.entity.StateEntity;
import com.gspl.customerregistration.repository.RepoCity;
import com.gspl.customerregistration.repository.RepoCountry;
import com.gspl.customerregistration.repository.RepoLocality;
import com.gspl.customerregistration.repository.RepoState;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;

@Service
public class GeographicalLocationService {

	@Autowired
	private RepoState repoState;

	@Autowired
	private RepoCountry repoCountry;

	@Autowired
	private RepoCity repoCity;

	@Autowired
	private RepoLocality repoLocality;

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	@Qualifier("messages")
	private MessageSource messageResource;

	public List<StateEntity> getAllStates() {
		return repoState.findAll();
	}

	public List<CountryEntity> getAllCountries() {
		return repoCountry.findAll();
	}

	public List<StateEntity> getAllStatesAsPerCountry(int countryId) {
		return repoState.findByCountryEntityCountryId(countryId);
	}

	public List<CityEntity> getAllCitiesAsPerState(int stateId) {
		return repoCity.findByStateEntityStateId(stateId);
	}

	public List<LocalityEntity> getAllLocalitiessAsPerCity(int cityId) {
		return repoLocality.findByCityEntityCityId(cityId);
	}

	public List<LocalityEntity> getLocalitesAsPerPinCode(int pinCode) {
		return repoLocality.findByPincode(String.valueOf(pinCode));
	}

	public String getPincodeByLocality(int localityId) {
		return repoLocality.findById(localityId).orElse(new LocalityEntity()).getPincode();
	}

	@Transactional
	public void uploadState(CountryEntity country, String... data) throws Exception {
		String countryCode = data[0].trim();
		String stateCode = data[1].trim();
		String stateName = data[2].trim();

		if ("".equals(stateCode)) {
			throw new RuntimeException(messageResource.getMessage("invalid.state.code", null, null, null));
		}

		if ("".equals(stateName)) {
			throw new RuntimeException(messageResource.getMessage("invalid.state.name", null, null, null));
		}

		if (repoState.existsByStateCode(stateCode)) {
			throw new RuntimeException(
					messageResource.getMessage("exists", new Object[] { messageResource.getMessage("state.code", null, null, null) }, null, null));
		}
		if (country == null) {

			if ("".equals(countryCode)) {
				throw new RuntimeException(messageResource.getMessage("invalid.country.code", null, null, null));
			}
			CountryEntity countryEntity = repoCountry.findTopByCountryCode(countryCode)
					.orElseThrow(() -> new RuntimeException(messageResource.getMessage("not.found.code",
							new Object[] { messageResource.getMessage("country.code", null, null, null), countryCode }, null, null)));

			StateEntity ent = new StateEntity();
			ent.setStateName(stateName);
			ent.setStateCode(stateCode);
			ent.setCountryEntity(countryEntity);
			repoState.save(ent);
		} else {
			StateEntity ent = new StateEntity();
			ent.setCountryEntity(country);
			ent.setStateCode(stateCode);
			ent.setStateName(stateName);
			repoState.save(ent);
		}

	}

	@Transactional
	public void uploadCity(StateEntity state, String... data) throws Exception {

		String stateCode = data[0].trim();
		String cityCode = data[1].trim();
		String cityName = data[2].trim();

		if ("".equals(cityCode)) {
			throw new Exception(messageResource.getMessage("invalid.city.code", null, null, null));
		}
		if ("".equals(cityName)) {
			throw new Exception(messageResource.getMessage("invalid.city.name", null, null, null));
		}
		if (repoCity.existsByCityCode(cityCode)) {
			throw new Exception(
					messageResource.getMessage("exists", new Object[] { messageResource.getMessage("city.code", null, null, null) }, null, null));
		}
		if (state == null) {

			if ("".equals(stateCode)) {
				throw new Exception(messageResource.getMessage("invalid.state.code", null, null, null));
			}
			StateEntity stateEntity = repoState.findTopByStateCode(stateCode)
					.orElseThrow(() -> new RuntimeException(messageResource.getMessage("not.found.code",
							new Object[] { messageResource.getMessage("state.code", null, null, null), stateCode }, null, null)));
			CityEntity ent = new CityEntity();
			ent.setCityName(cityName);
			ent.setCityCode(cityCode);
			ent.setStateEntity(stateEntity);
			repoCity.save(ent);

		} else {
			CityEntity ent = new CityEntity();
			ent.setCityName(cityName);
			ent.setCityCode(cityCode);
			ent.setStateEntity(state);
			repoCity.save(ent);
		}

	}

	@Transactional
	public void uploadLocality(CityEntity city, String... data) throws Exception {

		String cityCode = data[0].trim();
		String pinCode = data[1].trim();
		String localityName = data[2].trim();

		if ("".equals(pinCode)) {
			throw new Exception(messageResource.getMessage("invalid.pin.code", null, null, null));
		}

		if ("".equals(localityName)) {
			new Exception(messageResource.getMessage("invalid.locality.name", null, null, null));
		}
		if (repoLocality.existsByPincode(pinCode)) {
			throw new Exception(
					messageResource.getMessage("exists", new Object[] { messageResource.getMessage("pin.code", null, null, null) }, null, null));
		}
		if (city == null) {
			if ("".equals(cityCode)) {

				throw new Exception(messageResource.getMessage("invalid.city.code", null, null, null));

			}
			CityEntity cityEntity = repoCity.findTopByCityCode(cityCode).orElseThrow(() -> new RuntimeException(messageResource
					.getMessage("not.found.code", new Object[] { messageResource.getMessage("city.code", null, null, null), cityCode }, null, null)));
			LocalityEntity ent = new LocalityEntity();
			ent.setLocalityName(localityName);
			ent.setPincode(pinCode);
			ent.setCityEntity(cityEntity);
			repoLocality.save(ent);
		} else {
			LocalityEntity ent = new LocalityEntity();
			ent.setLocalityName(localityName);
			ent.setPincode(pinCode);
			ent.setCityEntity(city);
			repoLocality.save(ent);
		}

	}

	public List<LocalityEntity> getLocality() {
//		Query ps = entityManager.createQuery("SELECT l.localityName as localityName, l.pincode as pincode FROM LocalityEntity l where localityName=:lname");
//		ps.setFirstResult(10);
//		ps.setMaxResults(5);
//		ps.setParameter("lname", "Ghaziabad");
//		List<Map<String, String>> rs = ps.getResultList();

//		List<String> str = repoLocality.checkQuery("SELECT l.localityName as localityName FROM LocalityEntity l");

//		repoLocality.findLocalityNameAndPincodeMap();

		return repoLocality.findLocalityNameAndPincode();
	}

}
