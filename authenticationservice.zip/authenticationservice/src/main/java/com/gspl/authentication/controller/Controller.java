package com.gspl.authentication.controller;

import org.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gspl.authentication.entity.LoginRequest;
import com.gspl.authentication.entity.LoginResponse;
import com.gspl.authentication.service.AuthService;

import lombok.extern.log4j.Log4j2;

@RestController
@RequestMapping("/Auth")
@Log4j2
public class Controller {

	@Autowired
	@Qualifier("messages")
	private MessageSource messageResource;

	@Autowired
	private AuthService authService;

	@PostMapping("/login")
	public ResponseEntity<LoginResponse> login(@RequestBody LoginRequest loginRequest) {
		LoginResponse loginResponse = new LoginResponse();
		try {
			authService.successHandler(loginRequest, loginResponse);
			return ResponseEntity.ok(loginResponse);

		} catch (UsernameNotFoundException unfe) {
			log.error("Exception during login: ", unfe.getLocalizedMessage());
			loginResponse.setErrors(unfe.getMessage());
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(loginResponse);
		} catch (Exception e) {
			log.error("Exception during login: ", e.getMessage());
			loginResponse.setErrors(messageResource.getMessage("invalid.cred", new String[] { "" }, null, null));
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(loginResponse);
		}
	}

	@PostMapping("/forgotPassword")
	public ResponseEntity<String> forgotPassword(@RequestBody LoginRequest loginRequest) {
		JSONArray errors = new JSONArray();
		try {
			authService.sendForgotPasswordMail(errors, loginRequest.getUsername(), loginRequest.getEmail(), false);
			return ResponseEntity.ok("SENT");
		} catch (Exception e) {
			log.error("error :: ", e);
			errors.put(e.getMessage());
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors.toString());
		}
	}

	@PostMapping("/forgotPasswordOTP")
	public ResponseEntity<String> forgotPasswordOTP(@RequestBody LoginRequest loginRequest) {
		JSONArray errors = new JSONArray();
		try {
			authService.sendForgotPasswordMail(errors, loginRequest.getUsername(), loginRequest.getEmail(), true);
			return ResponseEntity.ok("SENT");
		} catch (Exception e) {
			log.error("error :: ", e);
			errors.put(e.getMessage());
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors.toString());
		}
	}

	@PostMapping("/resetPassword")
	public ResponseEntity<String> resetPassword(@RequestBody LoginRequest loginRequest) {
		JSONArray errors = new JSONArray();
		try {
			authService.resetPassword(errors, loginRequest.getUsername(), loginRequest.getPwdReqCode(), loginRequest.getPassword(), false);
			return ResponseEntity.ok("Password Changed");
		} catch (Exception e) {
			log.error("error :: ", e);
			errors.put(e.getLocalizedMessage());
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors.toString());
		}
	}

	@PostMapping("/resetPasswordOTP")
	public ResponseEntity<String> resetPasswordOTP(@RequestBody LoginRequest loginRequest) {
		JSONArray errors = new JSONArray();
		try {
			authService.resetPassword(errors, loginRequest.getUsername(), loginRequest.getPwdReqCode(), loginRequest.getPassword(), true);
			return ResponseEntity.ok("Password Changed");
		} catch (Exception e) {
			log.error("error :: ", e);
			errors.put(e.getLocalizedMessage());
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors.toString());
		}
	}

}
