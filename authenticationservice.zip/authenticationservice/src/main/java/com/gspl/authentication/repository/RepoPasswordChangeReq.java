package com.gspl.authentication.repository;

import java.util.Date;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import com.gspl.authentication.entity.PasswordChangeReq;

public interface RepoPasswordChangeReq extends JpaRepository<PasswordChangeReq, Integer>, CrudRepository<PasswordChangeReq, Integer> {

	Optional<PasswordChangeReq> findTopByUserName(String userName);

	Optional<PasswordChangeReq> findTopByPasswordChangeReqNo(String passwordChangeReqNo);

	Optional<PasswordChangeReq> findTopByPasswordChangeReqNoAndGenerationDateIsGreaterThan(String passwordChangeReqNo, Date generationDate);

}
