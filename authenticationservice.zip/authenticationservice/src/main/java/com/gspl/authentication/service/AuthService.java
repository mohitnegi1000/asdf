package com.gspl.authentication.service;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import org.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gspl.authentication.entity.Ent;
import com.gspl.authentication.entity.LoginRequest;
import com.gspl.authentication.entity.LoginResponse;
import com.gspl.authentication.entity.PasswordChangeReq;
import com.gspl.authentication.repository.RepoEnt;
import com.gspl.authentication.repository.RepoModuleEntityRelation;
import com.gspl.authentication.repository.RepoPasswordChangeReq;
import com.gspl.authentication.security.JwtService;
import com.gspl.authentication.utility.CommonUtilities;
import com.gspl.authentication.utility.Constants;

import lombok.extern.log4j.Log4j2;

@Service
@Log4j2
public class AuthService {

	@Autowired
	private RepoEnt repoEnt;

	@Value("${MAX_FAILED_ATTEMPTS}")
	private int maxFailedAttempts;

	@Value("${LOCK_TIME_DURATION}")
	private int lockTimeDuration;

	@Autowired
	@Qualifier("messages")
	private MessageSource messageResource;

	@Autowired
	RepoPasswordChangeReq repoPasswordChangeReq;

	@Autowired
	MailService mailService;

	@Autowired
	CommonUtilities commonUtils;

	@Autowired
	private JwtService jwtService;

	@Autowired
	RepoModuleEntityRelation repoModuleEntityRelation;

	private final int minuteMultiplier = 60000;
	private final int dayBuffer = 1;
	private final int minuteBuffer = 5;

	public ResponseEntity<LoginResponse> successHandler(LoginRequest loginRequest, LoginResponse loginResponse) {
		Ent ent = repoEnt.findTopByUsername(loginRequest.getUsername()).orElseThrow(() -> new UsernameNotFoundException(
				messageResource.getMessage("invalid.cred", new String[] { loginRequest.getUsername() }, null, null)));

		if (!ent.isAccountEnabled() && ent.getLastAttemptDateTime().getTime() + lockTimeDuration * minuteMultiplier > System.currentTimeMillis()) {
			long lockTimeRemainingMillis = ent.getLastAttemptDateTime().getTime() + lockTimeDuration * minuteMultiplier - System.currentTimeMillis();
			long lockTimeRemainingMinutes = lockTimeRemainingMillis / minuteMultiplier;
			loginResponse
					.setErrors(messageResource.getMessage("acc.disabled", new Object[] { maxFailedAttempts, lockTimeRemainingMinutes }, null, null));
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(loginResponse);
		}

		BCryptPasswordEncoder bCrypt = new BCryptPasswordEncoder();
		if (!bCrypt.matches(loginRequest.getPassword(), ent.getPassword())) {
			return failureHandler(ent, loginResponse);
		}

		if (ent.getNoOfAttempts() > 0) {
			ent.setNoOfAttempts(0);
			ent.setAccountEnabled(true);
			Calendar cal = Calendar.getInstance();
			cal.set(1900, 0, 1, 0, 0, 0);
			ent.setLastAttemptDateTime(cal.getTime());
			repoEnt.save(ent);
		}

		HashMap<String, Object> extraClaims = new HashMap<>();
		extraClaims.put("entityTypeId", ent.getEntityType().getEntityTypeId());
		extraClaims.put("authIds", repoModuleEntityRelation.getAllAuthIdsByEntId(ent.getId()));
		loginResponse.setToken(jwtService.generateToken(extraClaims, ent));
		loginResponse.setEntityTypeId(ent.getEntityType().getEntityTypeId());
		loginResponse.setEntityId(ent.getId());

		return ResponseEntity.ok(loginResponse);
	}

	public ResponseEntity<LoginResponse> failureHandler(Ent ent, LoginResponse loginResponse) {
		try {
			if (ent.isAccountEnabled()) {
				if (ent.getNoOfAttempts() < maxFailedAttempts - 1) {
					loginResponse.setErrors(messageResource.getMessage("invalid.cred", null, null, null) + " " + messageResource
							.getMessage("attempts.remain", new Object[] { maxFailedAttempts - 1 - ent.getNoOfAttempts() }, null, null));
					ent.setNoOfAttempts(ent.getNoOfAttempts() + 1);
				} else {
					ent.setAccountEnabled(false);
					ent.setLastAttemptDateTime(new Date());
					loginResponse
							.setErrors(messageResource.getMessage("acc.disabled", new Object[] { maxFailedAttempts, lockTimeDuration }, null, null));
				}
			} else {
				long lockTimeRemainingMillis = ent.getLastAttemptDateTime().getTime() + lockTimeDuration * minuteMultiplier
						- System.currentTimeMillis();
				long lockTimeRemainingMinutes = lockTimeRemainingMillis / minuteMultiplier;
				if (lockTimeRemainingMinutes <= 0) {
					ent.setAccountEnabled(true);
					loginResponse.setErrors(messageResource.getMessage("invalid.cred", null, null, null) + " "
							+ messageResource.getMessage("attempts.remain", new Object[] { maxFailedAttempts - 1 }, null, null));
					ent.setNoOfAttempts(1);
				} else {
					loginResponse.setErrors(
							messageResource.getMessage("acc.disabled", new Object[] { maxFailedAttempts, lockTimeRemainingMinutes }, null, null));
				}

			}
			repoEnt.save(ent);
		} catch (Exception e) {
			log.error("Exception during failure handler: {}", e.getMessage());
			loginResponse.setErrors(messageResource.getMessage("error", new Object[] { e.getMessage() }, null, null));
		}
		return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(loginResponse);
	}

	@Transactional
	public void sendForgotPasswordMail(JSONArray errors, String userName, String userEmail, boolean isOTPbased) throws Exception {

		if (userName.isEmpty()) {
			errors.put(messageResource.getMessage("not.specified", new String[] { messageResource.getMessage("common.username", null, null, null) },
					null, null));
		}

		if (userEmail.isEmpty()) {
			errors.put(messageResource.getMessage("not.specified", new String[] { messageResource.getMessage("common.mail", null, null, null) }, null,
					null));
		}

		if (!errors.isEmpty()) {
			throw new Exception();
		}

		Ent userEmailFromDB = repoEnt.findTopByUsername(userName)
				.orElseThrow(() -> new UsernameNotFoundException(messageResource.getMessage("invalid.cred", new String[] { userName }, null, null)));

		if (!userEmail.equals(userEmailFromDB.getEmail())) {
			throw new Exception(messageResource.getMessage("wrong.email", null, null, null));
		}
		String reqNo = "";
		reqNo += insertChangePwdRequest(userName, !isOTPbased);
		if (!reqNo.isEmpty()) {
			if (isOTPbased) {
				mailService.sendMailViaConfig(Constants.MailEventId.FORGOT_PASSWORD_OTP, null, new String[] { userEmail }, new String[] { "" },
						new String[] { reqNo }, null, null, false);
			} else {
				mailService.sendMailViaConfig(Constants.MailEventId.FORGOT_PASSWORD, null, new String[] { userEmail }, new String[] { "" },
						new String[] { reqNo }, null, null, false);
			}
		}
	}

	@Transactional
	public void resetPassword(JSONArray errors, String userName, String pwdReqCode, String newPassword, boolean isOTPbased) throws Exception {

		if ("".equals(userName)) {
			errors.put(messageResource.getMessage("not.specified", new String[] { messageResource.getMessage("common.username", null, null, null) },
					null, null));
		}

		if ("".equals(newPassword)) {
			errors.put(messageResource.getMessage("not.specified", new String[] { messageResource.getMessage("common.password", null, null, null) },
					null, null));
		}

		if (!errors.isEmpty()) {
			throw new Exception(messageResource.getMessage("errors.present", null, null, null));
		}

		Ent ent = repoEnt.findTopByUsername(userName)
				.orElseThrow(() -> new UsernameNotFoundException(messageResource.getMessage("invalid.cred", new String[] { userName }, null, null)));

		Calendar cd = Calendar.getInstance();
		if (isOTPbased) {
			cd.add(Calendar.MINUTE, -minuteBuffer);
		} else {
			cd.add(Calendar.DATE, -dayBuffer);
		}

		PasswordChangeReq pcr = repoPasswordChangeReq.findTopByPasswordChangeReqNoAndGenerationDateIsGreaterThan(pwdReqCode, cd.getTime())
				.orElse(null);

		if (ent == null || pcr == null || !ent.getUsername().equals(pcr.getUserName())) {
			throw new Exception(messageResource.getMessage("invalid.action", null, null, null));
		}
		BCryptPasswordEncoder bCrypt = new BCryptPasswordEncoder();
		if (bCrypt.matches(newPassword, ent.getPassword())) {
			throw new Exception(messageResource.getMessage("password.same", null, null, null));
		}
		ent.setPassword(bCrypt.encode(newPassword));
		ent.setAccountEnabled(true);
		ent.setNoOfAttempts(0);
		Calendar cal = Calendar.getInstance();
		cal.set(1900, 0, 1, 0, 0, 0);
		ent.setLastAttemptDateTime(cal.getTime());
		repoEnt.save(ent);
//					pcr.setActive(false);
//					repoPasswordChangeReq.save(pcr);
		repoPasswordChangeReq.delete(pcr);
	}

//	public String insertChangePwdReq(String userName) throws Exception {
//		String changePwdReqNo = "";
//		try {
//			Random randInt = new Random(9123847 + new Date().getTime());
//			for (int i = 1; i < 1000; i++) {
//				changePwdReqNo = "";
//				String[] generations = commonUtils.simplifiedGetGen(16, 1, randInt);
//
//				changePwdReqNo = switch (String.valueOf(i).length()) {
//				case 1 -> generations[0].toUpperCase() + "0000" + i;
//				case 2 -> generations[0].toUpperCase() + "000" + i;
//				case 3 -> generations[0].toUpperCase() + "00" + i;
//				case 4 -> generations[0].toUpperCase() + "0" + i;
//				default -> generations[0].toUpperCase() + i;
//				};
//			}
//
//			PasswordChangeReq pcr = repoPasswordChangeReq.findTopByUserName(userName).orElse(null);
//			if (pcr != null) {
//				pcr.setPasswordChangeReqNo(changePwdReqNo);
//			} else {
//				pcr = new PasswordChangeReq();
//				pcr.setPasswordChangeReqNo(changePwdReqNo);
//				pcr.setUserName(userName);
//				pcr.setActive(true);
//			}
//			pcr.setGenerationDate(new Date());
//
//			repoPasswordChangeReq.save(pcr);
//
//			return changePwdReqNo;
//		} catch (Exception e) {
//			log.error("Error : ", e);
//		}
//		return changePwdReqNo;
//	}
//
	public String insertChangePwdRequest(String userName, boolean useLetters) throws Exception {
		String res = "";
		try {
			String str = "0123456789";
			int len = 6;

			if (useLetters) {
				str = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
				len = 17;
			}

			StringBuilder sb = new StringBuilder(len);
			for (int i = 0; i < len; i++) {
				int index = (int) (str.length() * Math.random());
				sb.append(str.charAt(index));
			}

			res = sb.toString();

			PasswordChangeReq pcr = repoPasswordChangeReq.findTopByUserName(userName).orElse(null);
			if (pcr != null) {
				pcr.setPasswordChangeReqNo(res);
			} else {
				pcr = new PasswordChangeReq();
				pcr.setPasswordChangeReqNo(res);
				pcr.setUserName(userName);
				pcr.setActive(true);
			}
			pcr.setGenerationDate(new Date());
			repoPasswordChangeReq.save(pcr);
			return res;
		} catch (Exception e) {
			log.error("Error : ", e);
		}
		return res;
	}
}
