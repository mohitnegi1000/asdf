package com.gspl.authentication.security;

import java.security.Key;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

import com.gspl.authentication.entity.Ent;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.UnsupportedJwtException;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import io.jsonwebtoken.security.SignatureException;

@Service
public class JwtService {
	@Value("${security.jwt.secret-key}")
	private String secretKey;

	@Value("${security.jwt.expiration-time}")
	private long jwtExpiration;

	@Autowired
	@Qualifier("messages")
	private MessageSource messageResource;

	public String extractUsername(String token) {
		return extractClaim(token, Claims::getSubject);
	}

	public <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
		final Claims claims = extractAllClaims(token);
		return claimsResolver.apply(claims);
	}

	public String generateToken(Ent ent) {
		return generateToken(new HashMap<>(), ent);
	}

	public String generateToken(Map<String, Object> extraClaims, Ent ent) {
		return buildToken(extraClaims, ent, jwtExpiration);
	}

	public long getExpirationTime() {
		return jwtExpiration;
	}

	private String buildToken(Map<String, Object> extraClaims, Ent ent, long expiration) {
		return Jwts.builder().setClaims(extraClaims).setSubject(ent.getUsername()).setIssuedAt(new Date(System.currentTimeMillis()))
				.setExpiration(new Date(System.currentTimeMillis() + expiration)).signWith(getSignInKey(), SignatureAlgorithm.HS256).compact();
	}

	public boolean isTokenValid(String token, Ent ent) {
		final String username = extractUsername(token);
		return username.equals(ent.getUsername()) && !isTokenExpired(token);
	}

	public boolean isTokenValidByUSername(String token, String userName) {
		final String username = extractUsername(token);
		return username.equals(userName) && !isTokenExpired(token);
	}

	private boolean isTokenExpired(String token) {
		return extractExpiration(token).before(new Date());
	}

	private Date extractExpiration(String token) {
		return extractClaim(token, Claims::getExpiration);
	}

	private Claims extractAllClaims(String token) {
		try {
			return Jwts.parserBuilder().setSigningKey(getSignInKey()).build().parseClaimsJws(token).getBody();
		} catch (SignatureException e) {
			throw new SignatureException(messageResource.getMessage("invalid.jwt.sign", null, null, null));
		} catch (ExpiredJwtException e) {
			throw new ExpiredJwtException(null, null, messageResource.getMessage("expired.jwt", null, null, null));
		} catch (UnsupportedJwtException e) {
			throw new UnsupportedJwtException(messageResource.getMessage("wrong.jwt", null, null, null));
		} catch (MalformedJwtException e) {
			throw new MalformedJwtException(messageResource.getMessage("malform.jwt", null, null, null));
		} catch (IllegalArgumentException e) {
			throw new IllegalArgumentException(messageResource.getMessage("illegal.args", null, null, null));
		}
	}

	private Key getSignInKey() {
		byte[] keyBytes = Decoders.BASE64.decode(secretKey);
		return Keys.hmacShaKeyFor(keyBytes);
	}
}
