package com.gspl.authentication.service;

import java.util.HashMap;

import org.json.JSONObject;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClient.RequestBodySpec;

import lombok.extern.log4j.Log4j2;

@Service
@Log4j2
public class RestWebClient {

	public JSONObject getJsonObject(HttpMethod methodType, String microserviceName, String mapping, HashMap<String, Object> requestParam,
			HashMap<String, String> requestHeader, HashMap<String, Object> requestBody, String jwt) {
		JSONObject jObject = null;

		try {

			RequestBodySpec webClient = WebClient.create(microserviceName + mapping).method(methodType).uri(uriBuilder -> {
				if (requestParam != null) {
					requestParam.forEach((key, value) -> {
						uriBuilder.queryParam(key, value);
					});
				}

				return uriBuilder.build();
			});

			if (requestHeader != null) {
				requestHeader.forEach((key, value) -> {
					webClient.header(key, value);
				});
			}

			if (requestBody != null) {
				webClient.bodyValue(requestBody);
			}

			if (!"".equals(jwt)) {
				webClient.header("Authentication", jwt);
			}

			String response = webClient.retrieve().bodyToMono(String.class).block();
			try {
				jObject = new JSONObject(response);
			} catch (Exception e) {
				jObject = new JSONObject();
				jObject.put("respone", response);
			}

		} catch (Exception e) {
			log.error("Error : ", e);
//			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
		return jObject;
	}

}
