package com.gspl.authentication.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.gspl.authentication.entity.EntityType;

public interface RepoEntType extends JpaRepository<EntityType, Integer>, JpaSpecificationExecutor<EntityType> {

}
