package com.gspl.authentication.entity;

import org.hibernate.annotations.ColumnDefault;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "cmsMailSmsConfig")
public class MailSMSConfigEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)

	public int mailId;

	@ColumnDefault("'0'")
	private short mailEventId;

	private String mailEventName;

	@ColumnDefault("''")
	private String subject;

	@ColumnDefault("''")
	private String matter;

	@ColumnDefault("'0'")
	private short recipientType;

	@ColumnDefault("'0'")
	private short mailSmsType;

}
