package com.gspl.authentication.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gspl.authentication.AuthenticationService;
import com.gspl.authentication.entity.Ent;
import com.gspl.authentication.entity.EntityType;
import com.gspl.authentication.service.ModuleService;
import com.gspl.authentication.service.RestWebClient;
import com.gspl.authentication.utility.Constants;

import lombok.extern.log4j.Log4j2;

@RestController
@RequestMapping("/Module")
@Log4j2
public class ModuleController {

	@Autowired
	@Qualifier("messages")
	private MessageSource messageResource;

	@Value("${server.path}")
	String serverPath;

	@Autowired
	private ModuleService moduleService;

//	@Autowired
//	private RestWebClient restWebClient;

	@GetMapping("/moduleHierarchyEntity")
	public ResponseEntity<Map<String, List<Object>>> moduleHierarchyEntity(@RequestParam int entityId) {
		try {
			// int entityTypeId = (int) jwtService.extractClaim(authentication, (Claims c)
			// -> c.get("entityTypeId"));
			JSONArray moduleList = moduleService.getAuthHierarchyByEntityId(entityId, -1);
			return ResponseEntity.ok(Map.of("moduleList", moduleList.toList()));
		} catch (Exception e) {
			log.error("error :: ", e);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
		}
	}

	@GetMapping("/myProfile")
	public ResponseEntity<Ent> myProfile(@RequestParam long entityId) {
		try {
			return ResponseEntity.ok(moduleService.myProfile(entityId));
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(new Ent());
		}
	}

	@GetMapping("/searchEntity")
	public ResponseEntity<Map<String, Object>> searchEntity() {
		List<EntityType> entityTypeList = moduleService.getEntityType();
		Map<String, Object> response = new HashMap<>();
		if (entityTypeList != null) {
			response.put("entity types", entityTypeList);
			return ResponseEntity.ok(response);
		}
		return ResponseEntity.notFound().build();
	}

	@GetMapping("/listEntity")
	public ResponseEntity<HashMap> listEntity(@RequestParam(required = false, defaultValue = "") String username,
			@RequestParam(required = false, defaultValue = "") String email, @RequestParam(required = false, defaultValue = "0") int entityTypeId,
			@PageableDefault(size = Constants.PAGE_SIZE, page = 0, sort = "id", direction = Direction.DESC) Pageable pageable) {

		HashMap customers = moduleService.listEntity(username, email, entityTypeId, pageable);

		return ResponseEntity.ok(customers);
	}

	@PostMapping("/createOrUpdateEntity")
	public ResponseEntity<String> createOrUpdateEntity(@RequestBody Ent entity) throws Exception {
		try {
			Ent ent = moduleService.saveOrUpdateEntity(entity);
			return ResponseEntity.ok(ent.getUsername());
		} catch (Exception e) {

			if (e instanceof DataIntegrityViolationException) {
				throw e;
			}

			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
		}
	}

	@GetMapping("/searchEntityTypes")
	public void searchEntityTypes() {

	}

	@GetMapping("/listEntityTypes")
	public ResponseEntity<Map<String, Object>> listEntityType(@RequestParam(required = false, defaultValue = "") String entityTypeCode,
			@RequestParam(required = false, defaultValue = "") String entityTypeName,
			@PageableDefault(size = 10, page = 0, sort = "entityTypeId", direction = Direction.DESC) Pageable pageable) {
		Map<String, Object> listMap = moduleService.getListEntityType(entityTypeCode, entityTypeName, pageable);
		return ResponseEntity.ok(listMap);
	}

	@GetMapping("/modulesByEntityType")
	public List<Object> modulesByEntityType(@RequestParam int entityTypeId) {
		return moduleService.getAuthEntsWithSelected(entityTypeId);
	}

	@PostMapping("/saveModuleEntityTypePermissions")
	public ResponseEntity<Map<String, String>> saveModuleEntityTypePermissions(@RequestBody Map<String, Object> requestBody,
			@RequestHeader(name = "Authentication") String authentication) {
//make this secure by entityttypeId from jwt Auth==1 + username, password
		HashMap<String, Object> authMap = new HashMap<>();
		authMap.put("authentication", authentication);
		int entityTypeId = (int) requestBody.get("typeId");
		ArrayList<Integer> authIds = (ArrayList<Integer>) requestBody.get("authIds");

		Set<String> authMsForRefresh = moduleService.saveModuleByEntityTypeId(entityTypeId, authIds);
		for (String authMS : authMsForRefresh) { // restart only those MS which are changed using web client
			//JSONObject job = restWebClient.getJsonObject(HttpMethod.GET, serverPath + authMS, "/Utility/restart", null, null, null, authentication);
			//System.out.println(job);
		}

		//AuthenticationService.restart();
		HashMap<String, String> hm = new HashMap<>();
		hm.put("success", "Updated");
		return ResponseEntity.ok(hm);
	}

	@GetMapping("/modulesByEntity")
	public List<Object> modulesByEntity(@RequestParam int entityId) {
		return moduleService.getAuthEntsWithSelects(entityId);
	}

	@PostMapping("/saveModuleEntityPermissions")
	public ResponseEntity<String> saveModuleEntityPermissions(@RequestBody Map<String, Object> requestBody) {
		int entid = (int) requestBody.get("id");
		ArrayList<Integer> authIds = (ArrayList<Integer>) requestBody.get("authIds");
		moduleService.saveModuleEnityRel(entid, authIds);

		return ResponseEntity.ok("DONE");

	}

}
