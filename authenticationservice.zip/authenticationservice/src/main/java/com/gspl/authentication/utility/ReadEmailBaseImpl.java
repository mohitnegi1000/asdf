//package com.gspl.authentication.utility;
//
//import java.util.List;
//import java.util.Properties;
//
//import io.jsonwebtoken.io.IOException;
//import jakarta.mail.Authenticator;
//import jakarta.mail.Folder;
//import jakarta.mail.Message;
//import jakarta.mail.MessagingException;
//import jakarta.mail.PasswordAuthentication;
//import jakarta.mail.Session;
//import jakarta.mail.Store;
//import jakarta.mail.internet.MimeBodyPart;
//
//public class ReadEmailBaseImpl implements ReadEmail {
//
//	protected static final String USERNAME = "*****@gmail.com";
//	protected static final String PASSWORD = "*******";
//
//	protected void process(final String PROTOCOL, final String HOST, final Properties props) throws MessagingException, IOException {
//		Authenticator auth = new Authenticator() {
//			@Override
//			protected PasswordAuthentication getPasswordAuthentication() {
//				return new PasswordAuthentication(ReadEmailPopImpl.USERNAME, ReadEmailPopImpl.PASSWORD);
//			}
//		};
//
//		Session session = Session.getDefaultInstance(props, auth);
//
//		Store store = session.getStore(PROTOCOL);
//		store.connect(HOST, ReadEmailPopImpl.USERNAME, ReadEmailPopImpl.PASSWORD);
//
//		Folder inbox = store.getFolder("INBOX");
//		inbox.open(Folder.READ_WRITE);
//
//		Message[] messages = inbox.getMessages();
//		for (Message message : messages) {
//			if (message != null) {
//				String sentDate = message.getSentDate().toString();
//				List<MimeBodyPart> attachments = getAttachments(message);
//				if (!attachments.isEmpty()) {
//					save(message, attachments);
//				}
//			}
//		}
//
//		inbox.close(true);
//		store.close();
//	}
//
//}
