package com.gspl.authentication.entity;

import java.util.Date;

import org.hibernate.annotations.ColumnDefault;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "cmsPasswordChangeReq")
public class PasswordChangeReq {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int passwordChangeReqId;

	private String passwordChangeReqNo = "";

	private String userName = "";

	@Column(name = "generation_date", columnDefinition = "TIMESTAMP DEFAULT '1900-01-01 00:00'")
	@DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm")
	Date generationDate;

	@ColumnDefault("true")
	private boolean isActive = true;

}
