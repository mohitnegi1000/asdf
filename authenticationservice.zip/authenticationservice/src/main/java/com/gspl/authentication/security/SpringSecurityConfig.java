package com.gspl.authentication.security;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.CsrfConfigurer;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import com.gspl.authentication.repository.RepoModuleEntityTypeRelation;

@Configuration
@EnableWebSecurity
public class SpringSecurityConfig {

	@Autowired
	private RepoModuleEntityTypeRelation repoModuleEntityTypeRelation;

	@Autowired
	JwtAuthenticationFilter jwtAuthenticationFilter;

	@Value("${spring.application.name}")
	private String msName;

	@Bean
	SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

//		 specific dynamic authorities
//		List<Map<String, Object>> lister = repoModuleEntityTypeRelation.springSecuritySpecificAuths(msName);
//		for (Map<String, Object> authorizationEntity : lister) {
//			http.authorizeHttpRequests(requests -> requests.requestMatchers((String) authorizationEntity.get("authorizationmapping"))
//					.hasAnyAuthority((String[]) authorizationEntity.get("authorities")));
//		}
//
////		 general dynamic authorities
//		lister = repoModuleEntityTypeRelation.springSecurityGeneralAuths(msName);
//		for (Map<String, Object> authorizationEntity : lister) {
//			http.authorizeHttpRequests(requests -> requests.requestMatchers((String) authorizationEntity.get("authorizationmapping"))
//					.hasAnyAuthority((String[]) authorizationEntity.get("authorities")));
//		}

//		 static authorities
//		http.authorizeHttpRequests(requests -> requests.requestMatchers("/Auth/**").permitAll());

//		 deny by default
		http.authorizeHttpRequests(requests -> requests.anyRequest().permitAll());
//		http.authorizeHttpRequests(requests -> requests.anyRequest().denyAll());

//		 JWT filter
		http.addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);

//		 CORS
		http.csrf((Customizer<CsrfConfigurer<HttpSecurity>>) CsrfConfigurer::disable).cors(c -> c.configurationSource(corsConfigurationSource()));

		return http.build();
	}

	@Bean
	CorsConfigurationSource corsConfigurationSource() {
		CorsConfiguration configuration = new CorsConfiguration();
		configuration.setAllowedOriginPatterns(Arrays.asList("http://localhost*"));
		configuration.setAllowedMethods(Arrays.asList("GET", "POST"));
		configuration.setAllowedHeaders(Arrays.asList("*"));
//		configuration.setAllowCredentials(true);
		UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		source.registerCorsConfiguration("/**", configuration);
		return source;
	}

}
