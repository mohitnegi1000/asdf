package com.gspl.authentication.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.gspl.authentication.entity.AuthorizationEntity;

public interface RepoAuthorization extends JpaRepository<AuthorizationEntity, Integer>, CrudRepository<AuthorizationEntity, Integer> {

//	List<AuthorizationEntity> findByIsMenuItemTrueAndEntityTypeEntityTypeId(int entityTypeId);

	List<AuthorizationEntity> findByIsMenuItemTrueAndParentId(int parentId);

	@Query("SELECT new AuthorizationEntity(CAE.authorizationMapping as  authorizationMapping, CAE.authorizationId as authorizationId) FROM AuthorizationEntity CAE")
	List<AuthorizationEntity> getAuthObject();

	@Query("SELECT new AuthorizationEntity(CAE.authorizationMapping as  authorizationMapping, CAE.authorizationId as authorizationId) FROM AuthorizationEntity CAE WHERE CAE.isDefault=true")
	List<AuthorizationEntity> getAuthObjectDefaults();

	@Query("SELECT CAE.authorizationId FROM AuthorizationEntity CAE WHERE CAE.isMenuItem=false AND CAE.parentId=:parentId")
	Set<Integer> findByIsMenuItemFalseAndParentId(int parentId);

	@Query("SELECT CAE.authorizationId FROM AuthorizationEntity CAE WHERE CAE.authorizationMapping IN(:authMappings)")
	Set<Integer> findAllAuthorizationIdByAuthorizationMappingIn(List<String> authMappings);

}
