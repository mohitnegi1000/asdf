package com.gspl.authentication.entity;

import org.hibernate.annotations.ColumnDefault;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "cmsAuthorizationEntity")
public class AuthorizationEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int authorizationId;

	private String authorizationMS;
	private String authorizationName;
	private String authorizationMapping;

	@ColumnDefault("false")
	private boolean isMenuItem;

	@ColumnDefault("-1")
	private int parentId;

	@ColumnDefault("''")
	private String icon = "";

	@Transient
	@JsonProperty
	boolean isSelected;

	@ColumnDefault("false")
	private boolean isDefault;
}
