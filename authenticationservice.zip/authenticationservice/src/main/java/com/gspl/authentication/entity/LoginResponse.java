package com.gspl.authentication.entity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LoginResponse {
	private String token = "";
	private String errors = "";
	private long entityId;
	private int entityTypeId;
}
