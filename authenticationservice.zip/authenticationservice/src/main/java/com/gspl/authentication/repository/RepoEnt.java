package com.gspl.authentication.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import com.gspl.authentication.entity.Ent;

public interface RepoEnt extends JpaRepository<Ent, Long>, JpaSpecificationExecutor<Ent> {

	Optional<Ent> findTopByUsername(String name);

	@Query(nativeQuery = true, value = "SELECT JWT()")
	String getJWTKey();

	boolean existsByUsername(String username);

}
