package com.gspl.authentication.utility;

public final class Constants {

	public static final int PAGE_SIZE = 20;

	public static final class AuthorizationMS {
		public static final String AUTHENTICATION = "AuthenticationService";
		public static final String CUSTOMER = "CustomerRegistration";
	}

	public static class MailSmsType {
		public static final int INACTIVE = 0;
		public static final int MAIL = 1;
		public static final int SMS = 2;
	}

	public static final class EntityTypeCode {
		public static final String DEFAULT = "";
		public static final String SUPERADMIN = "SA";
		public static final String MSP = "MSP";
		public static final String BCM = "BCM";
		public static final String RSM = "RSM";
	}

	public static class MailEventId {
		public static final int FORGOT_PASSWORD = 1;
		public static final int FORGOT_PASSWORD_OTP = 2;
	}

	private Constants() {
	}
}
