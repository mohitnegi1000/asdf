package com.gspl.authentication.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.gspl.authentication.entity.Ent;
import com.gspl.authentication.entity.ModuleEntityRelation;

public interface RepoModuleEntityRelation extends JpaRepository<ModuleEntityRelation, Integer>, CrudRepository<ModuleEntityRelation, Integer> {

	List<ModuleEntityRelation> findByEntIdAndAuthorizationEntityIsMenuItemTrue(Long entId);

	long deleteAllInBatchByEnt(Ent ent);

	List<ModuleEntityRelation> findAllByEnt(Ent ent);

//	List<ModuleEntityRelation> findAuthorityEntityByEntity(Ent ent);

//	List<Integer> findAuthorizationIdsByEnt(Ent ent);

	List<ModuleEntityRelation> findByEnt(Ent ent);

	List<ModuleEntityRelation> findByEntId(long entId);

	List<ModuleEntityRelation> findAllByEntId(int entityId);

	@Query("SELECT new List(l.authorizationEntity.authorizationId) FROM ModuleEntityRelation l WHERE ent.id = :entityId")
	List<String> getAllAuthIdsByEntId(long entityId);

	List<ModuleEntityRelation> findByEntIdAndAuthorizationEntityParentIdAndAuthorizationEntityIsMenuItemTrue(Long entId, int parentId);

}
