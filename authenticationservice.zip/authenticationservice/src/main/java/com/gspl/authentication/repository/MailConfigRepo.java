package com.gspl.authentication.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gspl.authentication.entity.MailSMSConfigEntity;

public interface MailConfigRepo extends JpaRepository<MailSMSConfigEntity, Integer> {

	Optional<MailSMSConfigEntity> findTopByMailEventId(int mailEventId);

}
