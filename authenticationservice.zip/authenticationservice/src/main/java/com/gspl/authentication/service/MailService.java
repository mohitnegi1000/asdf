package com.gspl.authentication.service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.nio.charset.Charset;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.gspl.authentication.entity.MailSMSConfigEntity;
import com.gspl.authentication.repository.MailConfigRepo;
import com.gspl.authentication.utility.Constants;

import jakarta.mail.internet.MimeMessage;
import jakarta.persistence.EntityNotFoundException;
import lombok.extern.log4j.Log4j2;

@Service
@Log4j2
public class MailService {

	@Autowired
	@Qualifier("messages")
	private MessageSource messageResource;

	@Autowired
	JavaMailSender javaMailSender;

	@Autowired
	MailConfigRepo mailRepo;

	@Value("${smtp.mail.from}")
	String smtpMailFrom;

	@Value("${sms.url}")
	String smsUrl;

	@Value("${enableSMS}")
	boolean enableSMS;

	public void sendMail(String from, String subject, String matter, String[] to, String[] cc, String[] bcc, boolean hasAttachment,
			String... fileAttachments) throws Exception {
		MimeMessage mimeMessage = javaMailSender.createMimeMessage();
		MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage, true);

		if (from == null || "".equals(from)) {
			mimeMessageHelper.setFrom(smtpMailFrom);
		} else {
			mimeMessageHelper.setFrom(from);
		}

		if (to == null || to.length < 1) {
			mimeMessageHelper.setTo(smtpMailFrom);
		} else {
			mimeMessageHelper.setTo(to);
		}

		if ("".equals(matter)) {
			mimeMessageHelper.setText(smtpMailFrom, hasAttachment);
		} else {
			mimeMessageHelper.setText(matter, false);
		}

		if ("".equals(subject)) {
			mimeMessageHelper.setSubject("");
		} else {
			mimeMessageHelper.setSubject(subject);
		}

		if (cc != null && cc.length > 0) {
			mimeMessageHelper.setCc(cc);
		}

		if (bcc != null && bcc.length > 0) {
			mimeMessageHelper.setBcc(bcc);
		}

//		if (bcc != null && bcc.length > 0) {
//			InternetAddress[] bccAddresses = new InternetAddress[bcc.length];
//			for (int i = 0; i < bcc.length; i++) {
//				bccAddresses[i] = new InternetAddress(bcc[i]);
//			}
//			mimeMessageHelper.setBcc(bccAddresses);
//		}

		if (hasAttachment && fileAttachments != null) {
			FileSystemResource fileResource;
			for (String file : fileAttachments) {
				fileResource = new FileSystemResource(file);
				mimeMessageHelper.addAttachment(fileResource.getFilename(), fileResource);
			}
		}
		log.info(mimeMessage);
		javaMailSender.send(mimeMessage);
	}

	public void sendMailViaConfig(int id, String from, String[] to, String[] subjectVar, String[] matterVar, String[] cc, String[] bcc,
			boolean hasAttachment, String... fileAttachments) throws Exception {

		MailSMSConfigEntity entityRepo = mailRepo.findTopByMailEventId(id)
				.orElseThrow(() -> new EntityNotFoundException(messageResource.getMessage("mail.id.not.found", new Object[] { id }, null, null)));

		int mailEventId = entityRepo.getMailEventId();
		int mailSmsType = entityRepo.getMailSmsType();
//		int receipientType = entityRepo.getRecipientType();
		String subject = entityRepo.getSubject();
		String matter = entityRepo.getMatter();

		if (mailSmsType == Constants.MailSmsType.MAIL) {

			if (mailEventId == Constants.MailEventId.FORGOT_PASSWORD) {
				matter = matter.replaceFirst("\\#1", matterVar[0] == null || "".equals(matterVar[0]) ? "-" : matterVar[0]);
			}

			if (mailEventId == Constants.MailEventId.FORGOT_PASSWORD_OTP) {
				matter = matter.replaceFirst("\\#1", matterVar[0] == null || "".equals(matterVar[0]) ? "-" : matterVar[0]);
			}

		} else if (mailSmsType == Constants.MailSmsType.SMS) {
			log.info("OTP");
		} else {
			// Constants.MailSmsType.INACTIVE
			log.info("Inactive");
		}

		sendMail(from, subject, matter, to, cc, bcc, hasAttachment, fileAttachments);
	}

	public String sendSMS(String textMessage, String... custPhone) {
		String message = "", smsUrl = "";
		URL url;
		BufferedReader in = null;
		HttpURLConnection huc;
		try {
			for (String phone : custPhone) {
				smsUrl = smsUrl + URLEncoder.encode(phone, Charset.defaultCharset()) + "&msg="
						+ URLEncoder.encode(textMessage, Charset.defaultCharset());

				url = new URL(smsUrl);
				log.info("url::" + url);
				if (enableSMS) { // check to send mobile SMS
					URLConnection uc = url.openConnection();
					huc = (HttpURLConnection) uc;
					huc.setRequestMethod("POST");
//					new CommonUtilities().setTimeouts(huc);
					in = new BufferedReader(new InputStreamReader(huc.getInputStream()));
					message = in.readLine();
					log.info(message);
				} else {
					log.info("[[[NOT SENDING SMS AS enableSMS is false]]]");
				}
			}
		} catch (Exception ex) {
			log.error("Error in sending SMS", ex);
		} finally {
			try {
				if (in != null) {
					in.close();
				}
			} catch (Exception e) {
				log.error("Error in sending SMS catch", e);
			}
		}
		return message;
	}

}
