package com.gspl.authentication.controller;

import java.util.HashMap;
import java.util.Map;

import org.hibernate.exception.ConstraintViolationException;
import org.postgresql.util.PSQLException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.jdbc.BadSqlGrammarException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.fasterxml.jackson.databind.exc.InvalidFormatException;

import lombok.extern.log4j.Log4j2;

@RestController
@RestControllerAdvice
@Log4j2
public class GlobalController {

	@Autowired
	@Qualifier("messages")
	private MessageSource messageResource;

	@ExceptionHandler(BadSqlGrammarException.class)
	public ResponseEntity<String> exception(BadSqlGrammarException ex) {
		log.error("ERROR Exception :: at : ", ex);
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(messageResource.getMessage("sql.injection", null, null, null));
	}

	@ExceptionHandler(DataIntegrityViolationException.class)
	public ResponseEntity<Map<String, String>> exception(DataIntegrityViolationException ex) {
		return ResponseEntity.internalServerError().body(new HashMap<>() {
			{
				put("error", "Duplicate : " + ((PSQLException) ((ConstraintViolationException) ex.getCause()).getSQLException())
						.getServerErrorMessage().getDetail().split("[(.*)]")[1]);
			}
		});
	}

	@ExceptionHandler(HttpMessageNotReadableException.class)
	public ResponseEntity<Map<String, String>> exception(HttpMessageNotReadableException ex) {
		if (ex.getCause() instanceof InvalidFormatException) {
			return ResponseEntity.internalServerError().body(

					new HashMap<>() {
						{
							put("error", "Invalid " + ((InvalidFormatException) ex.getCause()).getPath().get(0).getFieldName());
						}
					}

			);
		}
		return ResponseEntity.internalServerError().body(new HashMap<>() {
			{
				put("error", ex.getLocalizedMessage());
			}
		});
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<Map<String, String>> exception(Exception ex) {
		log.error("ERROR Exception :: ", ex);
		return ResponseEntity.internalServerError().body(new HashMap<>() {
			{
				put("error", ex.getLocalizedMessage());
			}
		});

	}

}
