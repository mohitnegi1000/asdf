package com.gspl.authentication.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.gspl.authentication.entity.EntityType;
import com.gspl.authentication.entity.ModuleEntityTypeRelation;

public interface RepoModuleEntityTypeRelation extends JpaRepository<ModuleEntityTypeRelation, Integer> {

	@Query(value = """
			SELECT
				(SELECT AUTHORIZATION_MAPPING FROM CMS_AUTHORIZATION_ENTITY CTC WHERE CTC.AUTHORIZATION_ID = CT.AUTHORIZATION_ID) AS AUTHORIZATIONMAPPING,
				 ARRAY_AGG(CT.ENTITY_TYPE_ID::VARCHAR) AS AUTHORITIES
			FROM PUBLIC.CMS_ENTITY_TYPE_MODULE_REL AS CT
			WHERE AUTHORIZATION_ID IN
					(SELECT AUTHORIZATION_ID FROM CMS_AUTHORIZATION_ENTITY WHERE AUTHORIZATIONMS = :authms AND RIGHT(AUTHORIZATION_MAPPING,1)<>'*')
			GROUP BY AUTHORIZATION_ID
				""", nativeQuery = true)
	List<Map<String, Object>> springSecuritySpecificAuths(String authms);
	// STRING_AGG(CT.ENTITY_TYPE_ID::text, ',') AS ENTITYTYPEID,

	@Query(value = """
			SELECT
				(SELECT AUTHORIZATION_MAPPING FROM CMS_AUTHORIZATION_ENTITY CTC WHERE CTC.AUTHORIZATION_ID = CT.AUTHORIZATION_ID) AS AUTHORIZATIONMAPPING,
				 ARRAY_AGG(CT.ENTITY_TYPE_ID::VARCHAR) AS AUTHORITIES
			FROM PUBLIC.CMS_ENTITY_TYPE_MODULE_REL AS CT
			WHERE AUTHORIZATION_ID IN
					(SELECT AUTHORIZATION_ID FROM CMS_AUTHORIZATION_ENTITY WHERE AUTHORIZATIONMS = :authms AND RIGHT(AUTHORIZATION_MAPPING,1)='*')
			GROUP BY AUTHORIZATION_ID
				""", nativeQuery = true)
	List<Map<String, Object>> springSecurityGeneralAuths(String authms);
	// STRING_AGG(CT.ENTITY_TYPE_ID::text, ',') AS ENTITYTYPEID,

	@Query("SELECT new List(l.authorizationEntity.authorizationId) FROM ModuleEntityTypeRelation l WHERE entityType.entityTypeId = :entityTypeId")
	List<String> getAllAuthIdsByEntityTypeId(int entityTypeId);

	List<ModuleEntityTypeRelation> findByAuthorizationEntityIsMenuItemTrueAndEntityTypeEntityTypeIdAndAuthorizationEntityParentId(int entityTypeId,
			int parentId);

	long deleteAllInBatchByEntityType(EntityType entityType);

	@Query("SELECT new List(l.authorizationEntity.authorizationMS) FROM ModuleEntityTypeRelation l WHERE authorizationEntity.authorizationId IN (:authIds) AND authorizationEntity.authorizationMS<>'AuthenticationService'")
	Set<String> findDistinctAuthorizationMSByAuthorizationIdIn(ArrayList<Integer> authIds);

	@Query("SELECT new List(l.authorizationEntity.authorizationId) FROM ModuleEntityTypeRelation l WHERE entityType.entityTypeCode = :entityTypeCode")
	Set<String> getAllAuthIdsByEntityTypeCode(String entityTypeCode);

}
