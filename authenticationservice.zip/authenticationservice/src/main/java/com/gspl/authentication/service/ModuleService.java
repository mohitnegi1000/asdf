package com.gspl.authentication.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Hibernate;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gspl.authentication.entity.AuthorizationEntity;
import com.gspl.authentication.entity.Ent;
import com.gspl.authentication.entity.EntityType;
import com.gspl.authentication.entity.ModuleEntityRelation;
import com.gspl.authentication.entity.ModuleEntityTypeRelation;
import com.gspl.authentication.repository.RepoAuthorization;
import com.gspl.authentication.repository.RepoEnt;
import com.gspl.authentication.repository.RepoEntType;
import com.gspl.authentication.repository.RepoModuleEntityRelation;
import com.gspl.authentication.repository.RepoModuleEntityTypeRelation;
import com.gspl.authentication.utility.CommonUtilities;
import com.gspl.authentication.utility.Constants;

import jakarta.persistence.EntityExistsException;
import jakarta.persistence.EntityNotFoundException;

@Service
public class ModuleService {

	@Autowired
	private RepoEnt repoEnt;

	@Autowired
	@Qualifier("messages")
	private MessageSource messageResource;

	@Autowired
	MailService mailService;

	@Autowired
	CommonUtilities commonUtils;

	@Autowired
	RepoAuthorization repoAuthorization;

	@Autowired
	RepoModuleEntityTypeRelation repoModuleEntityTypeRelation;

	@Autowired
	RepoModuleEntityRelation repoModuleEntityRelation;

	@Autowired
	private AuthService authService;

	@Autowired
	RepoEntType repoEntType;

	public Ent myProfile(long entityId) throws Exception {
		Ent ent = repoEnt.findById(entityId).orElseThrow(() -> new EntityNotFoundException("Entity not found for id:" + entityId));
		ent.setPassword(null);
		return ent;
	}

	public JSONArray getAuthHierarchyByEntityId(int entityId, int parentId) {
		JSONArray jar = new JSONArray();
		JSONObject job;
		List<ModuleEntityRelation> list = repoModuleEntityRelation
				.findByEntIdAndAuthorizationEntityParentIdAndAuthorizationEntityIsMenuItemTrue((long) entityId, parentId);
		for (ModuleEntityRelation moduleEntity : list) {
			job = new JSONObject();
			job.put("parent", moduleEntity);
			JSONArray subMenu = getAuthHierarchyByEntityId(entityId, moduleEntity.getAuthorizationEntity().getAuthorizationId());
			if (!subMenu.isEmpty()) {
				job.put("subMenu", subMenu);
			}
			jar.put(job);
		}
		return jar;
		// return
		// repoModuleEntityRelation.findByEntIdAndAuthorizationEntityIsMenuItemTrue((long)
		// entityId);
	}

	@Transactional
	public Ent saveOrUpdateEntity(Ent ent) throws Exception {
		String email = ent.getEmail();
		String username = ent.getUsername();

		if ("".equals(email) || !email.contains("@")) {
			throw new Exception("Email invalid ");
		}

		if ("".equals(ent.getPassword()) || !commonUtils.validatePasswordReg(ent.getPassword())) {
			throw new Exception("Password is not Valid");
		}

		if (ent.getId() != 0 && !repoEnt.existsByUsername(username)) {
			throw new EntityExistsException("Username Already Present");
		}
		ent.setPassword(new BCryptPasswordEncoder().encode(ent.getPassword()));
		ent = repoEnt.save(ent);

		String reqNo = authService.insertChangePwdRequest(username, true);
		if (!reqNo.isEmpty()) {
			mailService.sendMailViaConfig(Constants.MailEventId.FORGOT_PASSWORD, null, new String[] { email }, new String[] { "" },
					new String[] { reqNo }, null, null, false);
		}

		return ent;
	}

	public HashMap<String, Object> getListEntityType(String entityCode, String entityName, Pageable pageable) {
		Specification<EntityType> ssSpecification = entityTypeSpecification(entityCode, entityName);

		HashMap<String, Object> map = new HashMap<>();
		long count = repoEntType.count(ssSpecification);
		map.put("count", count);
		if (count > 0) {
			map.put("list", repoEntType.findAll(ssSpecification, pageable).getContent());
		}

		return map;

	}

	public Specification<EntityType> entityTypeSpecification(String entityCode, String entityName) {
		Specification<EntityType> ssSpecification = Specification.where(EntityType.specsEqual())
				.and((root, query, cb) -> cb.notEqual(root.get("entityTypeCode"), Constants.EntityTypeCode.SUPERADMIN))
				.and((root, query, cb) -> entityCode == null || "".equals(entityCode) ? cb.conjunction()
						: cb.equal(root.get("entityTypeCode"), entityCode))
				.and((root, query, cb) -> entityName == null || "".equals(entityName) ? cb.conjunction()
						: cb.equal(root.get("entityTypeName"), entityName));
		return ssSpecification;

	}

	public List<Object> getAuthEntsWithSelected(int entityTypeId) {
		List<String> selectList = repoModuleEntityTypeRelation.getAllAuthIdsByEntityTypeId(entityTypeId);
		Set<String> saList = repoModuleEntityTypeRelation.getAllAuthIdsByEntityTypeCode(Constants.EntityTypeCode.SUPERADMIN);
		return getAuthEntities(-1, selectList, saList).toList();
	}

	public JSONArray getAuthEntities(int parentId, List<String> selectList, Set<String> saList) {
		JSONArray jar = new JSONArray();
		JSONObject job;
		List<AuthorizationEntity> list = repoAuthorization.findByIsMenuItemTrueAndParentId(parentId);
		for (AuthorizationEntity authorizationEntity : list) {
			if (saList.contains(String.valueOf(authorizationEntity.getAuthorizationId())))
				continue;
			job = new JSONObject();
			authorizationEntity.setSelected(selectList.contains(String.valueOf(authorizationEntity.getAuthorizationId())));
			job.put("parent", authorizationEntity);
			JSONArray subMenu = getAuthEntities(authorizationEntity.getAuthorizationId(), selectList, saList);
			if (!subMenu.isEmpty()) {
				job.put("subMenu", subMenu);
			}
			jar.put(job);
		}
		return jar;
	}

	@Transactional
	public Set<String> saveModuleByEntityTypeId(int entityTypeId, ArrayList<Integer> authIds) {
		EntityType entityType = repoEntType.findById(entityTypeId)
				.orElseThrow(() -> new EntityNotFoundException("Entity not found for id:" + entityTypeId));
		List<ModuleEntityTypeRelation> mrsList = new ArrayList<>();
		ModuleEntityTypeRelation mr;
		AuthorizationEntity authorizationEntity;
		Set<Integer> sets = getMappingChildren(new HashSet<>(authIds));
		// sets.addAll(repoAuthorization.findAllAuthorizationIdByAuthorizationMappingIn(Constants.DEFAULT_MAPPINGS));
		for (int authId : sets) {
			mr = new ModuleEntityTypeRelation();
			mr.setEntityType(entityType);
			authorizationEntity = new AuthorizationEntity();
			authorizationEntity.setAuthorizationId(authId);
			mr.setAuthorizationEntity(authorizationEntity);
			mrsList.add(mr);
		}
		repoModuleEntityTypeRelation.deleteAllInBatchByEntityType(entityType);
		repoModuleEntityTypeRelation.saveAll(mrsList);
		Set<String> authMsForRefresh = repoModuleEntityTypeRelation.findDistinctAuthorizationMSByAuthorizationIdIn(authIds);
		return authMsForRefresh;
	}

	public List<Object> getAuthEntsWithSelects(long entityId) {
		List<String> selectList = repoModuleEntityRelation.getAllAuthIdsByEntId(entityId);
		int entityTypeId = repoEnt.findById(entityId).orElseThrow(() -> new EntityNotFoundException("Entity not found for id:" + entityId))
				.getEntityType().getEntityTypeId();
		return getAuthEntitiesByEntityTypeIdPerms(-1, selectList, entityTypeId).toList();
	}

	public JSONArray getAuthEntitiesByEntityTypeIdPerms(int parentId, List<String> selectList, int entityTypeId) {
		JSONArray jar = new JSONArray();
		JSONObject job;
		List<ModuleEntityTypeRelation> list = repoModuleEntityTypeRelation
				.findByAuthorizationEntityIsMenuItemTrueAndEntityTypeEntityTypeIdAndAuthorizationEntityParentId(entityTypeId, parentId);
		for (ModuleEntityTypeRelation moduleEntity : list) {
			job = new JSONObject();
			job.put("parent", moduleEntity);
			JSONArray subMenu = getAuthEntitiesByEntityTypeIdPerms(moduleEntity.getAuthorizationEntity().getAuthorizationId(), selectList,
					entityTypeId);
			if (!subMenu.isEmpty()) {
				job.put("subMenu", subMenu);
			}
			jar.put(job);

		}
		return jar;

	}

	@Transactional
	public void saveModuleEnityRel(long entId, ArrayList<Integer> authIds) {
		Ent ent = repoEnt.findById(entId).orElseThrow(() -> new EntityNotFoundException("Entity not found for id:" + entId));
		List<ModuleEntityRelation> mrsList = new ArrayList<>();
		ModuleEntityRelation mr;
		AuthorizationEntity authorizationEntity;

		Set<Integer> sets = getMappingChildren(new HashSet<>(authIds));
		// sets.addAll(repoAuthorization.findAllAuthorizationIdByAuthorizationMappingIn(Constants.DEFAULT_MAPPINGS));

		for (int authId : sets) {
			mr = new ModuleEntityRelation();
			mr.setEnt(ent);
			authorizationEntity = new AuthorizationEntity();
			authorizationEntity.setAuthorizationId(authId);
			mr.setAuthorizationEntity(authorizationEntity);
			mrsList.add(mr);
		}
		repoModuleEntityRelation.deleteAllInBatchByEnt(ent);
		repoModuleEntityRelation.saveAll(mrsList);
	}

	public Set<Integer> getMappingChildren(Set<Integer> authIds) {
		Set<Integer> authIdsChild = new HashSet<>(authIds);
		for (Integer authId : authIds) {
			Set<Integer> subs = repoAuthorization.findByIsMenuItemFalseAndParentId(authId);
			if (subs != null && !subs.isEmpty()) {
				authIdsChild.addAll(subs);
				authIdsChild.addAll(getMappingChildren(subs));
			}
		}
		return authIdsChild;
	}

	public List<EntityType> getEntityType() {
		return repoEntType.findAll(entityTypeSpecification(null, null));
	}

	public HashMap listEntity(String username, String email, int entityTypeId, Pageable pageable) {
		HashMap<String, Object> job = new HashMap<>();
		Specification<Ent> specs = entityFilterSpecification(username, email, entityTypeId);
		long count = repoEnt.count(specs);
		job.put("count", count);
		if (count > 0) {
			List<Ent> lst = repoEnt.findAll(specs, pageable).getContent();
			for (Ent ent : lst) {
				ent.setPassword(null);
				Hibernate.initialize(ent.getEntityType());
			}
			job.put("list", lst);
		}
		return job;
	}

	private Specification<Ent> entityFilterSpecification(String username, String email, int entityTypeId) {
		return Specification.where(Ent.specsEqual())
				.and((root, query, cb) -> "".equals(username) ? cb.conjunction() : cb.equal(root.get("username"), username))
				.and((root, query, cb) -> "".equals(email) ? cb.conjunction() : cb.equal(root.get("email"), email))
				.and((root, query, cb) -> entityTypeId == 0 ? cb.conjunction() : cb.equal(root.get("entityType").get("entityTypeId"), entityTypeId));
	}

}
